-- The roll window every raider with LootRuler gets when the loot master rolls an item out: the game's own
-- group loot frame (item slot, name plate, dice and coin, timer bar), with what LootRuler knows underneath:
-- who reserved it, whether you may roll, the highest roll so far, and who it went to.
--   dice  main spec: /roll (1-100), or your reserve on a reserved item
--   coin  off spec: /roll 99
--   green dice  a boosted roll: /roll 1+points to 100+points, spending your guild points if you win (boosted
--         rolls on, and you have points)
--   x     pass
--   a row of buttons under it: the loot master's own roll types ("Transmog": /roll 98), when the roll has them
-- Only what you may roll with can be clicked; the buttons just /roll, so the loot master's addon (or anyone
-- reading chat) counts them like any other roll.
local _, LR = ...
local U, K, R = LR.U, LR.K, LR.Roll
local UI = LR.UI

local W, H = 256, 98
local BID_W = 300             -- an auction's window: wider, for its price and three buttons in a row
local BAR = 140               -- the timer bar's width (it stops short of the coin)
local MAX = 4
local HIDE_AFTER = 8          -- a finished roll's window goes this long after it's over

local frames = {}             -- shown and spare windows
local anchor

local function modifiedClick(link)
  if IsModifiedClick and IsModifiedClick("CHATLINK") and ChatEdit_InsertLink then ChatEdit_InsertLink(link) return true end
  if IsModifiedClick and IsModifiedClick("DRESSUP") and DressUpItemLink then DressUpItemLink(link) return true end
  return false
end
UI.modifiedClick = modifiedClick

--- the name and quality colour of a link ("|cffa335ee|Hitem:...|h[Name]|h|r")
function LR.linkParts(link, id)
  local hex = tostring(link or ""):match("|c%x%x(%x%x%x%x%x%x)")
  local name = tostring(link or ""):match("|h%[(.-)%]|h")
  return name or LR.itemName(id), hex or LR.qualityHex(id)
end

---------------------------------------------------------------------- what the window says
local function me() return U.me() end

--- the line under the timer for an auction
local function bidStatus(copy)
  local G = LR.Gdkp
  local top = R.topBid(copy)
  if copy.state == "awarded" or (copy.state == "closed" and copy.winner) then
    local who, g = copy.winner or (top and top.p), copy.winN or (top and top.n)
    if not who then return "Nobody bid." end
    if U.samePlayer(who, me()) then return ("|cff1eff00It's yours, for %s!|r"):format(G.gold(g)) end
    return ("Sold to %s for %s."):format(U.short(who), G.gold(g))
  end
  if copy.state == "closed" then return "Nobody bid." end
  if copy.state == "cancelled" then return "Called off." end
  local max = copy.myMax and (" Your max: " .. G.gold(copy.myMax) .. ".") or ""
  if top and U.samePlayer(top.p, me()) then return ("|cff1eff00You have the highest bid.|r Nobody's bid more yet.%s"):format(max) end
  local how = copy.strict and "Or type \"bid\" and an amount in raid chat." or "Or type an amount in raid chat."
  return how .. max
end

--- the line under the timer, for a raider's copy of a roll
function UI.rollStatus(copy)
  if copy.mode == "BID" then return bidStatus(copy) end
  local mine = copy.rolled[R.key(me())]
  local top, tied = R.result(copy)
  local function who(e) return U.samePlayer(e.p, me()) and "you" or U.short(e.p) end
  if copy.state == "awarded" then
    if copy.winner and U.samePlayer(copy.winner, me()) then return "|cff1eff00It's yours!|r" end
    return copy.winner and ("Given to " .. U.short(copy.winner) .. ".") or "Given out."
  end
  if copy.state == "closed" and copy.gargul then
    if top then return ("Rolls closed. Highest: %s %d (%s). Gargul gives it out."):format(who(top), top.n, R.label(copy, top)) end
    return "Rolls closed. Gargul gives it out."
  end
  if copy.state == "closed" then
    if tied then return ("Tied at %d: %s. The loot master decides."):format(top.n, R.names(tied)) end
    -- the loot master says who won when they give it out
    if copy.confirm == "wait" and top then
      return ("Rolls closed. Highest: %s %d (%s). The loot master gives it out."):format(who(top), top.n, R.label(copy, top))
    end
    if copy.confirm == "confirmed" and copy.winner then       -- (an older loot master's Confirm)
      local e = copy.rolled[R.key(copy.winner)]
      local n, label = copy.winN or (e and e.n), e and R.label(copy, e) or (R.LABEL[copy.winKind] or copy.winKind or "")
      if U.samePlayer(copy.winner, me()) then return ("|cff1eff00You win with %s (%s).|r"):format(tostring(n), label) end
      return ("%s wins with %s (%s)."):format(U.short(copy.winner), tostring(n), label)
    end
    if top then
      if U.samePlayer(top.p, me()) then return ("|cff1eff00You win with %d (%s).|r"):format(top.n, R.label(copy, top)) end
      return ("%s wins with %d (%s)."):format(U.short(top.p), top.n, R.label(copy, top))
    end
    return "Rolls closed. Nobody rolled."
  end
  if copy.state == "cancelled" then return "Called off." end
  local highest = top and ((tied and "Tied at " or "Highest: ") .. (tied and (top.n .. " (" .. R.names(tied, 3) .. ")") or (who(top) .. " " .. top.n .. " (" .. R.label(copy, top) .. ")"))) or nil
  if mine then
    local left = copy.state == "open" and R.rollsLeft(copy, me()) or 0
    local line = (R.rollsFor(copy, me()) > 1 and "Your best: %d (%s)." or "You rolled %d (%s)."):format(mine.n, R.label(copy, mine))
    if left > 0 then line = line .. (" |cffffd100%s left (one for each reserve).|r"):format(U.plural(left, "roll")) end
    if top and top == mine and not tied then return line .. " |cff1eff00That's the highest.|r" end
    return line .. (highest and (" " .. highest .. ".") or "")
  end
  if copy.passedByMe then return "You passed." .. (highest and (" " .. highest .. ".") or "") end
  if copy.mode == "SR" then
    if R.inList(copy.who, me()) then
      local others = U.filter(copy.who, function(w) return not U.samePlayer(R.nameOf(w), me()) end)
      local n = R.rollsFor(copy, me())
      return "|cffffd100You reserved this" .. (n > 1 and (" " .. n .. " times: you roll " .. n .. " times, your best counts") or "") .. ".|r "
        .. (#others > 0 and ("Also reserved by " .. R.names(others, 3) .. ".") or "Nobody else did.")
    end
    return "Reserved by " .. R.names(copy.who, 4) .. ": only they roll."
  end
  if copy.mode == "TIE" then
    local others = U.filter(copy.who, function(w) return not U.samePlayer(R.nameOf(w), me()) end)
    return "A tie: you and " .. R.names(others, 3) .. " roll again."
  end
  if copy.mode == "PR" then
    local place = copy.n and (LR.Prio.place(copy.n) .. " ") or ""
    if R.inList(copy.who, me()) then
      local others = U.filter(copy.who, function(w) return not U.samePlayer(R.nameOf(w), me()) end)
      return ("|cff1eff00You're %son the priority list|r, with %s: you roll for it."):format(place, R.names(others, 3))
    end
    return ("Priority list: %s (%s) roll for this."):format(R.names(copy.who, 4), place ~= "" and U.trim(place) or "first")
  end
  if highest then return highest .. "." end
  local it = LR.ITEMS[copy.id]
  if it and not LR.usableBy(copy.id, LR.myClass()) then return "|cff9d9d9dYour class can't use this.|r" end
  local lo = R.boostRange(copy, me())
  if lo and copy.mode == "OPEN" then return ("Dice: main spec. Green dice: boosted (%d points). Coin: off spec."):format(lo - 1) end
  return "Dice: main spec. Coin: off spec."
end

--- what each button does for me now: kind ("SR" / "MS" / "OS") or false, and why not
local function buttonsFor(copy)
  local opts = R.options(copy, me())
  local can = {}
  for _, k in ipairs(opts) do can[k] = true end
  local rolledAlready = R.rollsLeft(copy, me()) == 0 or copy.passedByMe or copy.state ~= "open"
  local dice = (can.SR and "SR") or (can.MS and "MS") or (copy.mode == "TIE" and copy.tie ~= "OS" and can[copy.tie] and copy.tie) or false
  local coin = can.OS and "OS" or false
  local boost = can.BR and "BR" or false
  if rolledAlready then dice, coin, boost = false, false, false end
  return dice, coin, boost
end

---------------------------------------------------------------------- the frame
local function setButton(b, enabled)
  if enabled then b:Enable() b:SetAlpha(1) else b:Disable() b:SetAlpha(0.35) end
  if b.tex then b.tex:SetDesaturated(not enabled) end
end

local function rollButton(f, kind)
  local b = CreateFrame("Button", nil, f)
  b:SetSize(32, 32)
  local dice = kind ~= "coin"
  local up = dice and "Interface\\Buttons\\UI-GroupLoot-Dice-Up" or "Interface\\Buttons\\UI-GroupLoot-Coin-Up"
  b.tex = b:CreateTexture(nil, "ARTWORK")
  b.tex:SetTexture(up)
  b.tex:SetAllPoints()
  b:SetHighlightTexture(dice and "Interface\\Buttons\\UI-GroupLoot-Dice-Highlight" or "Interface\\Buttons\\UI-GroupLoot-Coin-Highlight", "ADD")
  b:SetPushedTexture(dice and "Interface\\Buttons\\UI-GroupLoot-Dice-Down" or "Interface\\Buttons\\UI-GroupLoot-Coin-Down")
  b:SetMotionScriptsWhileDisabled(true)
  b.label = K.fs(b, "GameFontNormalSmall")
  b.label:SetJustifyH("RIGHT")
  b.label:SetJustifyV("MIDDLE")
  b.label:SetPoint("RIGHT", b, "LEFT", -1, 0)
  if kind == "boost" then
    b.tex:SetVertexColor(0.45, 1, 0.45)
    -- the points, on the dice (there's no room beside it)
    b.label:SetFontObject("GameFontNormalSmall")
    b.label:ClearAllPoints()
    b.label:SetPoint("BOTTOM", b, "BOTTOM", 0, 1)
    b.label:SetJustifyH("CENTER")
  end
  return b
end

local function makeFrame(i)
  local f = CreateFrame("Frame", "LootRulerRollFrame" .. i, UIParent, "BackdropTemplate")
  f:SetSize(W, H)
  f:SetFrameStrata("DIALOG")
  f:SetToplevel(true)
  f:SetClampedToScreen(true)
  f:EnableMouse(true)
  f:SetMovable(true)
  f:RegisterForDrag("LeftButton")
  f:SetScript("OnDragStart", function() anchor:StartMoving() end)
  f:SetScript("OnDragStop", function()
    anchor:StopMovingOrSizing()
    local point, _, relPoint, x, y = anchor:GetPoint()
    LR.db.ui.rollPoint = { point, relPoint, x, y }
  end)

  f.slot = f:CreateTexture(nil, "ARTWORK")
  f.slot:SetTexture("Interface\\Buttons\\UI-EmptySlot")
  f.slot:SetSize(64, 64)
  f.slot:SetPoint("TOPLEFT", 3, -3)
  f.plate = f:CreateTexture(nil, "ARTWORK")
  f.plate:SetTexture("Interface\\MerchantFrame\\UI-Merchant-LabelSlots")
  f.plate:SetSize(128, 64)
  f.plate:SetPoint("LEFT", f.slot, "RIGHT", -9, -10)
  f.name = K.fs(f, "GameFontNormalSmall")
  f.name:SetSize(98, 30)
  f.name:SetJustifyV("MIDDLE")
  f.name:SetPoint("LEFT", f.slot, "RIGHT", -5, 5)
  f.dragon = f:CreateTexture(nil, "OVERLAY")
  f.dragon:SetTexture("Interface\\DialogFrame\\UI-DialogBox-Gold-Dragon")
  f.dragon:SetSize(120, 120)
  f.dragon:SetPoint("TOPLEFT", -30, 15)
  f.corner = f:CreateTexture(nil, "OVERLAY")
  f.corner:SetSize(32, 32)
  f.corner:SetPoint("TOPRIGHT", -6, -7)

  f.item = CreateFrame("Button", nil, f)
  f.item:SetSize(34, 34)
  f.item:SetPoint("TOPLEFT", f.slot, "TOPLEFT", 15, -15)
  f.item.icon = f.item:CreateTexture(nil, "ARTWORK")
  f.item.icon:SetAllPoints()
  K.hover(f.item)
  f.item:SetScript("OnEnter", function(self)
    local copy = f.copy
    if not copy then return end
    GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
    GameTooltip:SetHyperlink(copy.link)
    if copy.mode == "SR" then
      GameTooltip:AddLine(" ")
      GameTooltip:AddLine("Soft reserved by", 1, 0.82, 0)
      for _, w in ipairs(copy.who) do GameTooltip:AddLine(R.names({ w }), 1, 1, 1) end
    end
    GameTooltip:AddLine(" ")
    GameTooltip:AddLine("Rolled out by " .. U.short(copy.by), 0.7, 0.7, 0.7)
    GameTooltip:Show()
  end)
  f.item:SetScript("OnLeave", function() GameTooltip:Hide() end)
  f.item:SetScript("OnClick", function() if f.copy then modifiedClick(f.copy.link) end end)
  if not K.T.plate then
    -- (a flat look: no slot, name plate, dragon or corner art, and the item gets a thin black edge. Every piece keeps
    -- its place, so the window is laid out the same)
    f.slot:SetColorTexture(0, 0, 0, 0)
    f.plate:SetColorTexture(0, 0, 0, 0)
    f.dragon:SetTexture(nil)
    f.itemEdge = f:CreateTexture(nil, "BORDER")
    f.itemEdge:SetColorTexture(0, 0, 0, 1)
    f.itemEdge:SetPoint("TOPLEFT", f.item, "TOPLEFT", -1, 1)
    f.itemEdge:SetPoint("BOTTOMRIGHT", f.item, "BOTTOMRIGHT", 1, -1)
    f.item.icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
  end

  f.pass = K.closeButton(f)
  f.pass:SetPoint("TOPRIGHT", f.corner, "TOPRIGHT", 5, 5)
  f.pass:SetScript("OnClick", function()
    local copy = f.copy
    if copy and IsShiftKeyDown() then UI.alwaysDo(copy, "pass") end
    if copy and copy.state == "open" and not copy.rolled[R.key(me())] then LR.Rolls.pass(copy) end
    if copy then copy.closedByMe = true end
    UI.rollWindows()
  end)
  K.tooltipOn(f.pass, function(tt)
    local copy = f.copy
    tt:SetText((copy and copy.state == "open" and not copy.rolled[R.key(me())]) and "Pass" or "Close", 1, 1, 1)
  end)

  f.dice = rollButton(f, "dice")
  f.dice:SetPoint("TOPRIGHT", -37, -14)
  f.coin = rollButton(f, "coin")
  f.coin:SetPoint("TOP", f.dice, "BOTTOM", -2, 2)
  f.boost = rollButton(f, "boost")
  f.boost:SetPoint("RIGHT", f.dice, "LEFT", -2, 0)
  for _, b in ipairs({ f.dice, f.coin, f.boost }) do
    b:SetScript("OnClick", function(self)
      if f.copy and self.kind then
        if IsShiftKeyDown() and self ~= f.boost then UI.alwaysDo(f.copy, self.kind == "OS" and "OS" or "MS") end
        LR.Rolls.roll(f.copy, self.kind)
        UI.afterMyRoll(f.copy)
        UI.rollWindows()
      end
    end)
    b:SetScript("OnEnter", function(self)
      GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
      GameTooltip:SetText(self.tipTitle or "", 1, 1, 1)
      if self.tip then GameTooltip:AddLine(self.tip, 1, 0.82, 0, true) end
      if self ~= f.boost then GameTooltip:AddLine("Shift-click: always do this for this item.", 0.5, 0.8, 1, true) end
      GameTooltip:Show()
    end)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)
  end

  -- the timer bar, as the game draws it
  f.bar = CreateFrame("Frame", nil, f)
  f.bar:SetSize(BAR, 10)
  f.bar:SetPoint("TOPLEFT", f.slot, "BOTTOMLEFT", 13, 10)
  f.bar.bg = f.bar:CreateTexture(nil, "BACKGROUND")
  f.bar.bg:SetAllPoints()
  f.bar.bg:SetColorTexture(0, 0, 0, 1)
  f.bar.fill = f.bar:CreateTexture(nil, "BORDER")
  f.bar.fill:SetTexture(K.T.bar)
  f.bar.fill:SetPoint("TOPLEFT")
  f.bar.fill:SetPoint("BOTTOMLEFT")
  f.bar.fill:SetWidth(BAR)
  f.bar.border = f.bar:CreateTexture(nil, "ARTWORK")
  f.bar.border:SetTexture("Interface\\PaperDollInfoFrame\\UI-Character-Skills-BarBorder")
  f.bar.border:SetSize(BAR + 4, 20)
  f.bar.border:SetPoint("TOP", 0, 5)
  if not K.T.plate then
    f.bar.border:SetTexture(nil)
    f.bar.bg:ClearAllPoints()
    f.bar.bg:SetPoint("TOPLEFT", -1, 1)
    f.bar.bg:SetPoint("BOTTOMRIGHT", 1, -1)
  end
  -- the seconds left, on the bar
  f.secs = f.bar:CreateFontString(nil, "OVERLAY")
  K.themeFont(f.secs)
  f.secs:SetFontObject("GameFontHighlightSmall")
  f.secs:SetJustifyH("CENTER")
  f.secs:SetJustifyV("MIDDLE")
  f.secs:SetAllPoints()

  -- an auction: the highest bid, big, and one button that bids the least that beats it (UI.fillBid)
  f.price = K.fs(f, "GameFontHighlightLarge")
  f.price:SetPoint("TOPLEFT", 14, -72)
  f.priceBy = K.fs(f, "GameFontHighlightSmall")
  f.priceBy:SetPoint("BOTTOMLEFT", f.price, "BOTTOMRIGHT", 8, 1)
  f.bid = K.mainButton(f)
  f.bid:SetSize(96, 22)
  f.bid:SetPoint("TOPLEFT", 12, -96)
  f.bid:SetMotionScriptsWhileDisabled(true)
  f.bid:SetScript("OnClick", function(self)
    if not f.copy or not self.amount then return end
    -- shift-click: a max bid instead (LootRuler bids for me, up to it)
    if IsShiftKeyDown() then UI.maxBidSheet(f.copy, self.amount) return end
    LR.Rolls.bid(f.copy, self.amount)
  end)
  f.bid:SetScript("OnEnter", function(self)
    GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
    GameTooltip:SetText(self:GetText() or "", 1, 1, 1)
    if self.tip then GameTooltip:AddLine(self.tip, 1, 0.82, 0, true) end
    GameTooltip:AddLine("Shift-click: a max bid (LootRuler bids for you, up to it).", 0.5, 0.8, 1, true)
    GameTooltip:Show()
  end)
  f.bid:SetScript("OnLeave", function() GameTooltip:Hide() end)
  f.price:Hide() f.priceBy:Hide() f.bid:Hide()

  f.status = K.fs(f, "GameFontHighlightSmall")
  f.status:SetWidth(W - 28)
  f.status:SetPoint("TOPLEFT", 14, -72)
  f.status:SetWordWrap(true)
  -- the loot master's note on the item ("Warrior > Rogue")
  f.note = K.fs(f, "GameFontHighlightSmall")
  f.note:SetWidth(W - 28)
  f.note:SetPoint("TOPLEFT", f.status, "BOTTOMLEFT", 0, -4)
  f.note:SetTextColor(0.5, 0.8, 1)
  -- everyone's rolls that count, best first (Settings: rollList)
  f.list = K.fs(f, "GameFontHighlightSmall")
  f.list:SetWidth(W - 28)
  f.list:SetJustifyH("LEFT")
  -- the loot master's own roll types, in a row underneath
  f.extras = {}
  for i = 1, R.MAX_EXTRA do
    local b = CreateFrame("Button", nil, f, "BackdropTemplate")
    b:SetBackdrop(K.INSET)
    b:SetHeight(20)
    b.text = K.fs(b, "GameFontHighlightSmall")
    b.text:SetJustifyH("CENTER")
    b.text:SetJustifyV("MIDDLE")
    b.text:SetPoint("LEFT", 6, 0)
    b.text:SetPoint("RIGHT", -6, 0)
    K.hover(b)
    b:SetScript("OnClick", function(self)
      if self.action then self.action() return end
      if f.copy and self.kind then
        LR.Rolls.roll(f.copy, self.kind)
        UI.afterMyRoll(f.copy)
        UI.rollWindows()
      end
    end)
    K.tooltipOn(b, function(tt)
      if b.action then
        tt:SetText("Bid ahead", 1, 1, 1)
        tt:AddLine("On what's coming up next: LootRuler bids for you when it comes up, as little as it takes, up to what you say.", 1, 0.82, 0, true)
        return
      end
      local x = f.copy and R.extra(f.copy, b.kind or b.shows)
      if not x then return end
      tt:SetText(x.n, 1, 1, 1)
      tt:AddLine(("/roll %d. It counts after main spec and off spec."):format(x.hi), 1, 0.82, 0, true)
    end)
    b:Hide()
    f.extras[i] = b
  end

  f:SetScript("OnUpdate", function(self) UI.rollTick(self) end)
  f:Hide()
  return f
end

--- the list of rolls under the status line: the best that count, with how they count; the window grows to fit
local LIST_MAX = 5
local function rollList(f, copy)
  local good = (LR.db.settings.rollList and #copy.entries > 0) and R.standings(copy) or {}
  if #good == 0 then
    f.list:SetText("")
    f.list:Hide()
    return
  end
  local lines = {}
  for i = 1, math.min(LIST_MAX, #good) do
    local e = good[i]
    local class = (copy.classes and copy.classes[e.p]) or LR.classOf(e.p)
    local num = copy.mode == "BID" and LR.Gdkp.gold(e.n) or tostring(e.n)
    lines[#lines + 1] = ("%d. %s  %s  |cff9d9d9d%s|r"):format(i, U.classText(U.short(e.p), class), num, R.label(copy, e))
  end
  if #good > LIST_MAX then lines[#lines + 1] = ("|cff9d9d9d+%d more|r"):format(#good - LIST_MAX) end
  f.list:SetText(table.concat(lines, "\n"))
  f.list:Show()
end

--- a max bid: LootRuler bids for me, as little as it takes to keep me on top, up to it
function UI.maxBidSheet(copy, suggest)
  UI.show()
  UI.goldSheet("Max bid for " .. U.plain(copy.link), "LootRuler bids for you, as little as it takes to keep you on top, up to this. Nobody else sees it.",
    copy.myMax or suggest, function(g)
      local ok, why = LR.Rolls.myMax(copy, g)
      if not ok then UI.toast(why) end
    end)
end

--- a bid of any amount (not just the window's two): it's typed in raid chat, like theirs. lowest(): the least that counts now;
--- place(g): bids it
function UI.bidAmount(title, lowest, place)
  UI.show()
  UI.goldSheet(title, ("It's typed in raid chat for you, like the window's buttons. The lowest bid that counts now: %s."):format(LR.Gdkp.gold(lowest())),
    lowest(), function(g)
      local least = lowest()
      if g < least then        -- (too little: asked again)
        UI.bidAmount(title, lowest, place)
        UI.toast(("The lowest bid that counts now is %s."):format(LR.Gdkp.gold(least)))
        return
      end
      place(g)
    end, "Bid")
end

--- the row of the loot master's own roll types (a roll open to everyone that has them); in an auction, "Bid an amount",
--- and "Bid ahead" when more is to come (and the loot master's LootRuler takes bids ahead)
local function extraRow(f, copy)
  for _, b in ipairs(f.extras) do b.action = nil end
  -- a loot council member: a button to vote (Core/Council.lua)
  local s = LR.current()
  if LR.Council.isMember(s, U.me()) and LR.Council.votable(copy) and next(copy.rolled) then
    local b = f.extras[1]
    b.kind, b.shows = nil, nil
    b.action = function() UI.councilSheet(copy) end
    K.setChip(b, copy.myVote and ("Council: " .. U.short(copy.myVote)) or "Council: vote", false)
    setButton(b, true)
    b:ClearAllPoints()
    b:SetPoint("TOPLEFT", f.list:IsShown() and f.list or f.note:IsShown() and f.note or f.status, "BOTTOMLEFT", 0, -6)
    b:SetWidth(150)
    b:Show()
    for i = 2, #f.extras do f.extras[i]:Hide() end
    return true
  end
  if copy.mode == "BID" and copy.state == "open" then
    local top = R.topBid(copy)
    local b = f.extras[1]
    b.kind, b.shows = nil, nil
    b.action = function()
      UI.bidAmount("Bid on " .. LR.itemName(copy.id), function() return R.nextBid(copy) end, function(g) LR.Rolls.bid(copy, g) end)
    end
    K.setChip(b, "Bid an amount", false)
    setButton(b, not (top and U.samePlayer(top.p, me())))
    b:ClearAllPoints()
    b:SetPoint("LEFT", f.bid, "RIGHT", 6, 0)
    b:SetSize(100, 22)
    b:Show()
    local m = f.extras[2]
    m.kind, m.shows = nil, nil
    m.action = function() UI.maxBidSheet(copy, R.nextBid(copy)) end
    K.setChip(m, copy.myMax and ("Max " .. LR.Gdkp.gold(copy.myMax)) or "Max bid", false)
    setButton(m, true)
    m:ClearAllPoints()
    m:SetPoint("LEFT", b, "RIGHT", 4, 0)
    m:SetSize(copy.myMax and 80 or 64, 22)
    m:Show()
    local used = 2
    if copy.upNext and LR.hasFeature(copy.by, LR.FEATURE_AHEAD) then
      local a = f.extras[3]
      a.kind, a.shows = nil, nil
      a.action = function() UI.bidAheadSheet(copy) end
      local n = 0
      for _, id in ipairs(copy.upNext) do if LR.Rolls.myAhead[id] then n = n + 1 end end
      K.setChip(a, n > 0 and ("Bid ahead (%d)"):format(n) or "Bid ahead", false)
      setButton(a, true)
      a:ClearAllPoints()
      a:SetPoint("TOPLEFT", f.list:IsShown() and f.list or f.note:IsShown() and f.note or f.status, "BOTTOMLEFT", 0, -6)
      a:SetWidth(100)
      a:Show()
      used = 3
    end
    for i = used + 1, #f.extras do f.extras[i]:Hide() end
    return used == 3
  end
  local xk = copy.mode == "OPEN" and copy.xk or {}
  local can = {}
  if copy.state == "open" and not copy.rolled[R.key(me())] and not copy.passedByMe then
    for _, k in ipairs(R.options(copy, me())) do can[k] = true end
  end
  local prev
  for i, b in ipairs(f.extras) do
    local x = xk[i]
    if x then
      b.shows = "X" .. i
      b.kind = can[b.shows] and b.shows or nil
      K.setChip(b, ("%s (%d)"):format(x.n, x.hi), false)
      setButton(b, b.kind ~= nil)
      b:ClearAllPoints()
      if prev then b:SetPoint("LEFT", prev, "RIGHT", 4, 0)
      else b:SetPoint("TOPLEFT", f.list:IsShown() and f.list or f.note:IsShown() and f.note or f.status, "BOTTOMLEFT", 0, -6) end
      b:Show()
      prev = b
    else
      b.kind, b.shows = nil, nil
      b:Hide()
    end
  end
  return prev ~= nil
end

--- the note, the list and the row go under the status line; the window grows to fit them
local function underneath(f, copy)
  local lines = {}
  if copy.note then lines[#lines + 1] = "Note: " .. copy.note end
  if copy.wish and copy.mode ~= "BID" then lines[#lines + 1] = "Wishlist: " .. LR.wishLine(copy.wish, 4) end
  if copy.mine then lines[#lines + 1] = "|cff9d9d9dYou have:|r " .. table.concat(copy.mine, " ") end
  if copy.upNext and copy.state == "open" then
    local names = {}
    for i = 1, math.min(3, #copy.upNext) do names[#names + 1] = LR.coloredName(copy.upNext[i]) end
    local more = (copy.upNext.n or #copy.upNext) - #names
    lines[#lines + 1] = "|cff9d9d9dNext:|r " .. table.concat(names, ", ") .. (more > 0 and (" |cff9d9d9d+" .. more .. "|r") or "")
  end
  local noted = #lines > 0
  f.note:SetText(table.concat(lines, "\n"))
  f.note:SetShown(noted)
  f.list:ClearAllPoints()
  f.list:SetPoint("TOPLEFT", noted and f.note or f.status, "BOTTOMLEFT", 0, -4)
  rollList(f, copy)
  local row = extraRow(f, copy)
  local h = 72 + (f.bidH or 0) + f.status:GetStringHeight() + (noted and (4 + f.note:GetStringHeight()) or 0)
    + (f.list:IsShown() and (4 + f.list:GetStringHeight()) or 0) + (row and 26 or 0) + 14
  f:SetHeight(math.max(H, h))
end

local function fill(f, copy)
  f.copy = copy
  local name, hex = LR.linkParts(copy.link, copy.id)
  local q = LR.ITEMS[copy.id] and LR.quality(copy.id) or (hex == "ff8000" and 5 or hex == "a335ee" and 4 or 3)
  local epic = q >= 4
  if K.T.plate then
    f:SetBackdrop(epic and {
      bgFile = "Interface\\DialogFrame\\UI-DialogBox-Gold-Background", edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Gold-Border",
      tile = true, tileSize = 32, edgeSize = 32, insets = { left = 11, right = 12, top = 12, bottom = 11 } } or {
      bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background", edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
      tile = true, tileSize = 32, edgeSize = 32, insets = { left = 11, right = 12, top = 12, bottom = 11 } })
    f.corner:SetTexture(epic and "Interface\\DialogFrame\\UI-DialogBox-Gold-Corner" or "Interface\\DialogFrame\\UI-DialogBox-Corner")
    f.dragon:SetShown(epic)
  else
    -- (a flat look: its frame, with the edge in the item's colour when it's epic or better)
    K.skin(f, "rock")
    if epic and hex and #hex == 6 then
      f:SetBackdropBorderColor(tonumber(hex:sub(1, 2), 16) / 255, tonumber(hex:sub(3, 4), 16) / 255, tonumber(hex:sub(5, 6), 16) / 255, 1)
    end
    f.dragon:Hide()
  end
  f.item.icon:SetTexture(LR.itemIcon(copy.id))
  f.name:SetText("|cff" .. hex .. name .. "|r")

  if copy.mode == "BID" then
    -- an auction: the highest bid, big, and one red button that bids the least that beats it (it types it in raid chat);
    -- beside it, any amount, or a max bid
    local top = R.topBid(copy)
    local a1 = R.nextBid(copy)
    local open = copy.state == "open"
    local can = open and not (top and U.samePlayer(top.p, me()))
    f:SetWidth(BID_W)
    f.dice:Hide() f.coin:Hide() f.boost:Hide()
    f.dice.kind, f.coin.kind, f.boost.kind = nil, nil, nil
    f.name:SetWidth(98 + BID_W - W)
    f.status:SetWidth(BID_W - 28)
    f.note:SetWidth(BID_W - 28)
    f.list:SetWidth(BID_W - 28)
    f.price:SetShown(open) f.priceBy:SetShown(open) f.bid:SetShown(open)
    if open then
      f.price:SetText(top and LR.Gdkp.gold(top.n) or LR.Gdkp.gold(copy.min or 0))
      local who = top and (U.samePlayer(top.p, me()) and "you" or U.classText(U.short(top.p), (copy.classes and copy.classes[top.p]) or LR.classOf(top.p)))
      f.priceBy:SetText(top and ("highest, by " .. who) or "where bids start: nobody's bid yet")
      f.bid.amount = a1
      f.bid:SetText("Bid " .. LR.Gdkp.gold(a1))
      f.bid:SetWidth(math.max(80, f.bid:GetFontString():GetStringWidth() + 26))
      if can then f.bid:Enable() else f.bid:Disable() end
      local word = copy.strict and "bid " or ""
      f.bid.tip = ("Types \"%s%d\" in raid chat: the least that beats the highest bid."):format(word, a1)
      f.bidH = 54
      f.status:ClearAllPoints()
      f.status:SetPoint("TOPLEFT", 14, -126)
    else
      f.bidH = 0
      f.status:ClearAllPoints()
      f.status:SetPoint("TOPLEFT", 14, -72)
    end
    f.status:SetText(UI.rollStatus(copy))
    underneath(f, copy)
    return
  end
  -- (not an auction: the game's group loot window as it is)
  f:SetWidth(W)
  f.status:SetWidth(W - 28) f.note:SetWidth(W - 28) f.list:SetWidth(W - 28)
  f.price:Hide() f.priceBy:Hide() f.bid:Hide()
  f.bidH = 0
  f.status:ClearAllPoints()
  f.status:SetPoint("TOPLEFT", 14, -72)
  f.dice.amount, f.coin.amount = nil, nil
  local dice, coin, boost = buttonsFor(copy)
  local opts = R.options(copy, me())
  f.dice.kind, f.coin.kind, f.boost.kind = dice or nil, coin or nil, boost or nil
  setButton(f.dice, dice ~= false)
  setButton(f.coin, coin ~= false)
  setButton(f.boost, boost ~= false)
  -- the green dice: only for someone who has points, while the roll is open to everyone
  local lo, hi = R.boostRange(copy, me())
  local boosted = copy.mode == "OPEN" and lo ~= nil
  f.boost:SetShown(boosted)
  f.name:SetWidth(boosted and 86 or 98)
  if boosted then
    f.boost.label:SetText("+" .. (lo - 1))
    f.boost.tipTitle = "Boosted roll"
    f.boost.tip = ("/roll %d %d: main spec, with your %d guild points added. If you win, the points are spent."):format(lo, hi, lo - 1)
  end
  f.coin:SetShown(copy.mode == "OPEN" or (copy.mode == "TIE" and copy.tie == "OS"))
  if copy.mode == "TIE" and copy.tie == "OS" then
    f.dice:Hide()
    f.coin:ClearAllPoints()
    f.coin:SetPoint("TOPRIGHT", -37, -14)
  else
    f.dice:Show()
    f.coin:ClearAllPoints()
    f.coin:SetPoint("TOP", f.dice, "BOTTOM", -2, 2)
  end
  local srMine = copy.mode == "SR" and #opts > 0
  -- (beside a green dice there's no room for the label: the line underneath says which is which)
  f.dice.label:SetText(boosted and "" or srMine and "SR" or copy.mode == "SR" and "" or copy.mode == "TIE" and (R.LABEL[copy.tie] or "") or "MS")
  f.coin.label:SetText("OS")
  f.dice.tipTitle = srMine and "Roll for your reserve" or "Main spec"
  f.coin.tipTitle = "Off spec"
  f.coin.tip = "/roll 99. Main spec rolls win over off spec."
  if copy.mode == "SR" and not srMine then
    f.dice.tipTitle = "Soft reserved"
    f.dice.tip = "Only " .. R.names(copy.who, 4) .. " roll for this."
  elseif copy.mode == "TIE" then
    f.dice.tipTitle = "Roll again"
    local _, hi = R.kind(copy, copy.tie)
    local x = R.extra(copy, copy.tie)
    f.dice.tipTitle = x and ("Roll again: " .. x.n) or f.dice.tipTitle
    f.dice.tip = (hi and hi < 100 and ("/roll " .. hi) or "/roll") .. ", for the tie."
  elseif copy.mode == "PR" then
    f.dice.tipTitle = "Priority"
    f.dice.tip = "Only " .. R.names(copy.who, 4) .. ", who share the top priority, roll for this."
  else
    f.dice.tip = "/roll" .. (srMine and ": only players who reserved it roll." or " (1-100).")
  end
  if R.rollsLeft(copy, me()) == 0 and copy.rolled[R.key(me())] then f.dice.tip = "You've rolled." f.coin.tip = "You've rolled." f.boost.tip = "You've rolled."
  elseif copy.rolled[R.key(me())] then f.dice.tip = ("Roll again: %s left, and your best counts."):format(U.plural(R.rollsLeft(copy, me()), "roll")) end
  f.status:SetText(UI.rollStatus(copy))
  underneath(f, copy)
end

--- the timer bar and the seconds left (every frame)
function UI.rollTick(f)
  local copy = f.copy
  if not copy then return end
  local t = GetTime()
  if copy.state == "open" then
    local left = math.max(0, (copy.ends or t) - t)
    local frac = copy.secs > 0 and math.min(1, left / copy.secs) or 0
    f.bar.fill:SetWidth(math.max(1, BAR * frac))
    f.bar.fill:SetVertexColor(1, left <= 5 and 0.35 or 1, 0)
    local whole = math.ceil(left)
    if f.shownSecs ~= whole then f.shownSecs = whole f.secs:SetText(whole .. " sec") end
  else
    f.bar.fill:SetWidth(BAR)
    f.bar.fill:SetVertexColor(0.45, 0.45, 0.45)
    if f.shownSecs then f.shownSecs = nil f.secs:SetText("") end
    if copy.endedAt and t - copy.endedAt > HIDE_AFTER and f:IsShown() then
      -- (a loot council member's stays up until it's given out: they vote after the rolls are in)
      if copy.council == nil then copy.council = LR.Council.isMember(LR.current(), me()) end      -- (looked up once)
      if not (copy.council and copy.state == "closed" and LR.Council.votable(copy)) then
        copy.closedByMe = true
        UI.rollWindows()
      end
    end
  end
end

--- shift-click on a button: remember it as my rule for the item (Core/AutoRoll.lua)
function UI.alwaysDo(copy, action)
  LR.AutoRoll.set(copy.id, action)
  LR.print(("from now on, LootRuler will %s on %s for you. (Settings tab, Auto-roll, to change it.)"):format(
    action == "pass" and "pass" or ("roll " .. (action == "OS" and "off spec" or "main spec")), copy.link))
end

---------------------------------------------------------------------- which windows are up
local function wanted(copy)
  if copy.hidden or copy.closedByMe or copy.state == "cancelled" then return false end
  local set = LR.db.settings
  if not set.rollWindow then return false end
  if set.rollOnlyMine and #R.options(copy, me()) == 0 then return false end
  -- an item everyone may roll on that my class can't use (when the item is known)
  if set.rollHideUnusable and not copy.test and copy.mode == "OPEN" and LR.ITEMS[copy.id] and not LR.usableBy(copy.id, LR.myClass()) then return false end
  return true
end

UI.ROLL_SIZES = { { 0.8, "Small" }, { 1, "Normal" }, { 1.15, "Big" }, { 1.3, "Bigger" } }

--- I rolled from a window: it goes a moment later, when that's how I like it (Settings: rollCloseAfter)
function UI.afterMyRoll(copy)
  if not LR.db.settings.rollCloseAfter then return end
  C_Timer.After(1.5, function()
    if (copy.rolled[R.key(me())] and R.rollsLeft(copy, me()) == 0) or copy.passedByMe or (copy.myRoll and R.rollsFor(copy, me()) == 1) then
      copy.closedByMe = true
      UI.rollWindows()
    end
  end)
end

--- where roll windows go (the top of the first one): the player can drag it
function UI.rollAnchor()
  if not anchor then
    anchor = CreateFrame("Frame", "LootRulerRollAnchor", UIParent)
    anchor:SetSize(W, 1)
    anchor:SetMovable(true)
    anchor:SetClampedToScreen(true)
    local pt = LR.db.ui.rollPoint
    if pt then anchor:SetPoint(pt[1], UIParent, pt[2], pt[3], pt[4]) else anchor:SetPoint("TOP", UIParent, "CENTER", 0, -120) end
  end
  return anchor
end

--- shows a window for every roll that wants one (newest last), up to four
function UI.rollWindows()
  UI.rollAnchor()
  local show = {}
  for _, k in ipairs(LR.Rolls.order) do
    local copy = LR.Rolls.seen[k]
    if copy and wanted(copy) then show[#show + 1] = copy end
  end
  while #show > MAX do table.remove(show, 1) end
  local y = 0
  for i = 1, math.max(#show, #frames) do
    local copy = show[i]
    if copy then
      frames[i] = frames[i] or makeFrame(i)
      local f = frames[i]
      f:SetScale(LR.db.settings.rollScale or 1)
      fill(f, copy)
      f:ClearAllPoints()
      f:SetPoint("TOP", anchor, "TOP", 0, -y)              -- (each below the one before, however tall it's grown)
      y = y + f:GetHeight() + 4
      f:Show()
      UI.rollTick(f)
    elseif frames[i] then
      frames[i].copy = nil
      frames[i]:Hide()
    end
  end
  if UI.reserveStrip then UI.reserveStrip() end      -- (the strip goes with its window)
end

--- roll windows (and the loot master window) back where they start
function UI.resetPositions()
  if anchor then
    anchor:ClearAllPoints()
    anchor:SetPoint("TOP", UIParent, "CENTER", 0, -120)
  end
  if UI.masterDraw then UI.masterDraw() end
end

--- a roll started or changed (Core/Rolls.lua)
function UI.rollWindow(copy)
  local fresh = not copy.shownOnce
  copy.shownOnce = true
  if fresh and wanted(copy) then LR.sound(SOUNDKIT.RAID_WARNING or 8959) end
  if fresh then UI.reservedAlert(copy) end
  UI.rollWindows()
end

--- an item I reserved (or share the top of its priority list for) is being rolled out: I'm told in chat and in the
--- middle of the screen, with its own sound, and the game's icon flashes if I'm in another window. Once a roll.
--- Settings: reservedAlert.
function UI.reservedAlert(copy)
  if copy.alerted or copy.state ~= "open" or not LR.db.settings.reservedAlert then return end
  local line
  if (copy.mode == "SR" or copy.mode == "PR") and R.inList(copy.who, me()) then
    line = (copy.mode == "PR" and "You're on the priority list for %s: roll for it now!" or "You reserved %s: roll for it now!"):format(copy.link)
  elseif copy.mode == "OPEN" and copy.wish then
    -- on my thatsmybis wishlist (the loot master's addon says who in the group has it there)
    for _, e in ipairs(copy.wish) do
      if U.samePlayer(e.p, me()) then line = ("It's on your wishlist (%d): %s is being rolled for now!"):format(e.n, copy.link) end
    end
  end
  if not line then return end
  copy.alerted = true
  LR.print(line)
  if RaidNotice_AddMessage and RaidWarningFrame then RaidNotice_AddMessage(RaidWarningFrame, U.plain(line), ChatTypeInfo["RAID_WARNING"]) end
  C_Timer.After(0.8, function() LR.sound(SOUNDKIT.READY_CHECK or 8960) end)   -- (after the raid warning's sound)
  if FlashClientIcon then FlashClientIcon() end
end
--- someone bid more than me: a line, the middle of the screen and a sound (Settings: outbidAlert)
function UI.outbidAlert(copy, top)
  if not LR.db.settings.outbidAlert then return end
  local line = ("Outbid on %s: %s bid %s. Bid %s or more to get it back."):format(copy.link, U.short(top.p), LR.Gdkp.gold(top.n), LR.Gdkp.gold(R.nextBid(copy)))
  LR.print(line)
  if RaidNotice_AddMessage and RaidWarningFrame then RaidNotice_AddMessage(RaidWarningFrame, U.plain(line), ChatTypeInfo["RAID_WARNING"]) end
  UI.sound(SOUNDKIT.ALARM_CLOCK_WARNING_3 or 12889)
end
--- a LootRuler sound (all of them go through here)
function UI.sound(id) LR.sound(id) end
function UI.rollEnded(copy) UI.rollWindows() end
function UI.rollFrames() return frames end

LR.onChange(function(what)
  if what == "rolls" and LR.db then UI.atMostEvery("rolls", UI.REDRAW_GAP, UI.rollWindows) end
end)

-- made-up players for pretend rolls (the Test tab), with their classes
UI.PRETEND = LR.Practice.PEOPLE
--- the first n made-up players: who (names, with reserves), and their classes
function UI.pretendPlayers(n)
  local who, classes = {}, {}
  for i = 1, math.min(n or 0, #UI.PRETEND) do
    local name = UI.PRETEND[i][1] .. "-" .. U.realm()
    who[#who + 1] = { name, 1 }
    classes[name] = UI.PRETEND[i][2]
  end
  return who, classes
end
--- the item pretend rolls are for: the first of the session's raid, else Dragonspine Trophy
function UI.pretendItem()
  local s = LR.current()
  local raid = s and LR.raidOf(s)
  return raid and raid.order and raid.order[1] or 28830
end

--- the loot council's vote: everyone who rolled, with how they rolled and the votes so far
function UI.councilSheet(copy)
  UI.show()
  UI.openSheet("Loot council: " .. LR.itemName(copy.id), function(f, h)
    f:note("Vote for who gets it. You can change your vote until it's given out. The loot master sees the votes and hands it over.")
    local good = R.standings(copy)
    if #good == 0 then f:note("Nobody has rolled yet.") end
    for _, e in ipairs(good) do
      local votes = copy.votes and copy.votes[e.p]
      local b = K.get(f.owner, "item", f.parent)
      local mine = copy.myVote and U.samePlayer(copy.myVote, e.p)
      K.setItem(b, f.width, LR.LOGO, U.classText(U.short(e.p), (copy.classes and copy.classes[e.p]) or LR.classOf(e.p)),
        ("%s %d%s"):format(R.label(copy, e), e.n, votes and ("  |cff1eff00%s|r"):format(U.plural(votes, "vote")) or ""),
        mine and "|cff1eff00Your vote|r" or "",
        { text = mine and "Take back" or "Vote", width = 70, click = function()
          local ok, why = LR.Council.myVote(copy, mine and "" or e.p)
          if not ok then UI.toast(why) end
          h.redraw(true)
          UI.rollWindows()
        end })
      f:place(b, 36)
      f:gap(2)
    end
    if copy.voted then f:note(("%d of the council voted so far."):format(copy.voted)) end
  end, { full = true })
end

--- bids ahead on what's coming up after an auction: each item, my bid ahead on it, and a box to change it
function UI.bidAheadSheet(copy)
  UI.show()
  UI.openSheet("Bid ahead", function(f, h)
    f:note("The most you'll pay for an item coming up. When its auction starts, LootRuler bids for you, as little as it takes to keep you on top, up to that. Nobody else sees it. Players without the addon whisper the loot master \"!lr bid 300 [item]\".")
    for _, id in ipairs(copy.upNext or {}) do
      local mine = LR.Rolls.myAhead[id]
      local b = K.get(f.owner, "item", f.parent)
      K.setItem(b, f.width, LR.itemIcon(id), LR.coloredName(id), mine and ("Your bid ahead: up to " .. LR.Gdkp.gold(mine)) or "No bid ahead yet", "",
        { text = mine and "Change" or "Bid", width = 60, click = function()
          UI.goldSheet("Bid ahead on " .. LR.itemName(id), "The most you'll pay (0 takes it back).", mine, function(g)
            local ok, why = LR.Rolls.bidAhead(copy, id, g)
            if not ok then UI.toast(why) end
            h.redraw(true)
            UI.rollWindows()
          end)
        end })
      f:place(b, 36)
      f:gap(2)
    end
    local more = (copy.upNext and (copy.upNext.n or #copy.upNext) or 0) - (copy.upNext and #copy.upNext or 0)
    if more > 0 then f:note(("%s more after these."):format(U.plural(more, "item"))) end
  end, { full = true })
end

--- a pretend roll, only on this screen, to see the window (and move it): /lr test, and the Test tab.
--- opts: { mode = "OPEN" / "SR", reservers = how many made-up players reserved it, mine = I reserved it too, secs }
function UI.testRoll(opts)
  opts = opts or {}
  local id = UI.pretendItem()
  local k = "test:" .. GetTime()
  local who, classes = {}, nil
  if opts.mode == "SR" then
    who, classes = UI.pretendPlayers(opts.reservers or 3)
    if opts.mine then table.insert(who, 1, { U.me(), type(opts.mine) == "number" and opts.mine or 1 }) end   -- (mine: how many reserves)
  end
  local mode = opts.mode or "OPEN"
  local copy = R.new(k, id, { mode = mode, who = who, xk = mode == "OPEN" and R.checkKinds(LR.db.settings.rollKinds) or nil })
  copy.by = U.me()
  copy.link = LR.itemLink(id)
  copy.note = LR.noteFor(id)
  copy.classes = classes
  local secs = opts.secs or 20
  copy.secs, copy.ends, copy.state, copy.test = secs, GetTime() + secs, "open", true
  LR.Rolls.seen[k] = copy
  table.insert(LR.Rolls.order, k)
  if not opts.quiet then LR.print("a pretend roll window, only on your screen. Drag it to where you'd like roll windows to be.") end
  UI.rollWindow(copy)
  LR.changed("rolls")
  C_Timer.After(secs, function()
    if copy.state == "open" then copy.state = "closed" copy.endedAt = GetTime() UI.rollWindows() LR.changed("rolls") end
  end)
  return copy
end

--- a pretend Gargul roll: the strip shows, as it would for Gargul's line in raid chat (nothing is said in chat)
function UI.testGargul(reservers, secs, mine)
  local id = UI.pretendItem()
  local roll = LR.Gargul.startRoll(id, LR.itemLink(id), secs or 20, GetTime())
  roll.who, roll.classes = UI.pretendPlayers(reservers or 3)
  roll.test = true
  -- its roll window, as a raider without Gargul sees it (the made-up players reserved it, and roll)
  local copy = LR.Rolls.followGargul(id, LR.itemLink(id), secs or 20, U.me(), true)
  copy.who, copy.classes = U.copy(roll.who), roll.classes
  if mine then table.insert(copy.who, 1, { U.me(), 1 }) table.insert(roll.who, 1, { U.me(), 1 }) end
  copy.mode = #copy.who > 0 and "SR" or "OPEN"
  roll.copy = copy
  UI.rollWindows()
  LR.changed("gargul")
  C_Timer.After(secs or 20, function()
    if LR.Gargul.roll == roll then LR.Gargul.endRoll() LR.Rolls.gargulEnded(id) UI.rollWindows() end
  end)
  return roll
end
