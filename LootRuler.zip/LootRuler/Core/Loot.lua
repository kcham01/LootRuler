-- The raids and their loot: lookups, which items a class can use, and item names, links and icons from the
-- game (with the English names from Data/Loot.lua until the game has the item loaded).
local _, LR = ...
local U = LR.U

LR.RAID_BY_KEY = {}
for _, r in ipairs(LR.RAIDS) do
  LR.RAID_BY_KEY[r.key] = r
  r.has = {}           -- item id -> true
  r.order = {}         -- every item once, in list order
  for _, b in ipairs(r.bosses) do
    for _, id in ipairs(b.items) do
      if not r.has[id] then r.has[id] = true r.order[#r.order + 1] = id end
    end
  end
end

-- each raid's instance, as the game numbers it (GetInstanceInfo's instance id; GetSavedInstanceInfo's map id)
LR.RAID_MAPS = {
  MoltenCore = 409, Onyxia = 249, BlackwingLair = 469, ["Zul'Gurub"] = 309, TheRuinsofAhnQiraj = 509, TheTempleofAhnQiraj = 531,
  Naxxramas = 533, Karazhan = 532, GruulsLair = 565, MagtheridonsLair = 544, SerpentshrineCavern = 548, TempestKeep = 550,
  HyjalSummit = 534, BlackTemple = 564, ZulAman = 568, SunwellPlateau = 580,
}
LR.WORLD_RAIDS = { WorldBosses = true, WorldBossesBC = true }       -- (outdoors: no instance)
local RAID_AT = {}
for key, map in pairs(LR.RAID_MAPS) do RAID_AT[map] = key end
--- the raid (key) whose instance this is, or nil
function LR.raidAt(map) return map and RAID_AT[map] end

--- where I am: { map = the instance's number, kind = "raid" / "party" / "none" (outdoors) / ..., name }
function LR.where()
  local name, kind, _, _, _, _, _, map = GetInstanceInfo()
  return { map = map, kind = kind or "none", name = name or "" }
end

function LR.raid(key) return key and LR.RAID_BY_KEY[key] end
function LR.raidHas(key, id) local r = LR.RAID_BY_KEY[key] return r and r.has[id] or false end

LR.CUSTOM = "custom"         -- a session's raid key for a raid that isn't in the built-in lists

--- a session's raid: the built-in one, or (for a raid that isn't in this version's lists: one the leader
--- named, or one a newer version knows) a stand-in with its name and no bosses
local stubs = setmetatable({}, { __mode = "k" })
function LR.raidOf(s)
  local r = s and LR.RAID_BY_KEY[s.raid]
  if r then return r end
  local stub = s and stubs[s]
  local name = s and type(s.raidName) == "string" and s.raidName ~= "" and s.raidName or "the raid"
  if not stub or stub.name ~= name then
    stub = { key = s and s.raid or LR.CUSTOM, name = name, short = name, bosses = {}, order = {}, has = {}, custom = true }
    if s then stubs[s] = stub end
  end
  return stub
end

--- whether a session lets an item be reserved: any item for a raid that isn't in the lists, or when the
--- leader allows any item; else the raid's own loot. lenient: don't judge by the built-in lists at all (a
--- raider's addon, before asking the leader's, which decides)
LR.MAX_ITEM_ID = 2147483647      -- (the game's item numbers are 32-bit)
function LR.allowedItem(s, id, lenient)
  if type(id) ~= "number" or id <= 0 or id % 1 ~= 0 or id > LR.MAX_ITEM_ID then return false end
  if lenient or s.any or not LR.RAID_BY_KEY[s.raid] then return true end
  return LR.RAID_BY_KEY[s.raid].has[id] == true
end

--- an item id from what someone typed or linked: an item link, "item:123" or just a number
function LR.idFrom(text)
  text = tostring(text or "")
  return tonumber(text:match("|Hitem:(%d+)")) or tonumber(text:match("^%s*item:(%d+)")) or tonumber(text:match("^%s*%[?(%d+)%]?%s*$"))
end

--- which bosses in a raid drop an item (names)
function LR.dropsFrom(key, id)
  local out = {}
  local r = LR.RAID_BY_KEY[key]
  for _, b in ipairs(r and r.bosses or {}) do
    if U.indexOf(b.items, id) then out[#out + 1] = b.name end
  end
  return out
end

---------------------------------------------------------------------- who can use what (TBC)
LR.CLASS_BIT = { WARRIOR = 1, PALADIN = 2, HUNTER = 4, ROGUE = 8, PRIEST = 16, SHAMAN = 64, MAGE = 128, WARLOCK = 256, DRUID = 1024 }
local ARMOR = {      -- item class 4 subclasses each class can wear
  [2] = { ROGUE = 1, HUNTER = 1, SHAMAN = 1, DRUID = 1, WARRIOR = 1, PALADIN = 1 },   -- leather
  [3] = { HUNTER = 1, SHAMAN = 1, WARRIOR = 1, PALADIN = 1 },                        -- mail
  [4] = { WARRIOR = 1, PALADIN = 1 },                                                -- plate
  [6] = { WARRIOR = 1, PALADIN = 1, SHAMAN = 1 },                                    -- shields
  [7] = { PALADIN = 1 }, [8] = { DRUID = 1 }, [9] = { SHAMAN = 1 },                  -- librams, idols, totems
}
local WEAPON = {     -- item class 2 subclasses each class can learn
  WARRIOR = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 10, 13, 15, 16, 18 },
  PALADIN = { 0, 1, 4, 5, 6, 7, 8 },
  HUNTER = { 0, 1, 2, 3, 6, 7, 8, 10, 13, 15, 16, 18 },
  ROGUE = { 2, 3, 4, 7, 13, 15, 16, 18 },
  PRIEST = { 4, 10, 15, 19 },
  SHAMAN = { 0, 1, 4, 5, 10, 13, 15 },
  MAGE = { 7, 10, 15, 19 },
  WARLOCK = { 7, 10, 15, 19 },
  DRUID = { 4, 5, 10, 13, 15 },
}
local WEAPON_OK = {}
for cls, list in pairs(WEAPON) do WEAPON_OK[cls] = {} for _, s in ipairs(list) do WEAPON_OK[cls][s] = true end end

--- whether a class (token, "PALADIN") can use an item: class-only items (tier tokens) and the armour and
--- weapons it can equip. Recipes, gems, quest items and mounts are for everyone.
function LR.usableBy(id, cls)
  local it = LR.ITEMS[id]
  if not it or not cls then return true end
  local mask, class, sub = it[7], it[4], it[5]
  if mask and mask ~= -1 and LR.CLASS_BIT[cls] and bit.band(mask, LR.CLASS_BIT[cls]) == 0 then return false end
  if class == 4 and ARMOR[sub] then return ARMOR[sub][cls] == 1 end
  if class == 2 then return WEAPON_OK[cls] and WEAPON_OK[cls][sub] or false end
  return true
end

-- the armour each class wears (TBC, level 40 and up)
local BEST_ARMOR = { WARRIOR = 4, PALADIN = 4, HUNTER = 3, SHAMAN = 3, ROGUE = 2, DRUID = 2, PRIEST = 1, MAGE = 1, WARLOCK = 1 }

--- what a class would reserve: what it can use, and of armour only its own kind (plate for a paladin, not
--- the cloth it could also wear). Cloaks, jewellery, weapons, tokens and everything else as LR.usableBy.
function LR.forClass(id, cls)
  if not LR.usableBy(id, cls) then return false end
  local it = LR.ITEMS[id]
  if it and it[4] == 4 and it[5] >= 1 and it[5] <= 4 and it[3] ~= 16 and BEST_ARMOR[cls] then return it[5] == BEST_ARMOR[cls] end
  return true
end

local ALLIANCE, HORDE = 1101, 690
--- items that only drop for one faction (Magtheridon's Head) are hidden from the other
function LR.forFaction(id, faction)
  local it = LR.ITEMS[id]
  local race = it and it[8]
  if not race or race == -1 or not faction then return true end
  if faction == "Alliance" then return race == ALLIANCE end
  if faction == "Horde" then return race == HORDE end
  return true
end

---------------------------------------------------------------------- names, links, icons
local QUALITY = { [0] = "9d9d9d", [1] = "ffffff", [2] = "1eff00", [3] = "0070dd", [4] = "a335ee", [5] = "ff8000" }
-- where an item is worn: its inventory type (the loot lists' third field, or the game's INVTYPE_ name) -> the
-- character's slots (a ring or a trinket has two; a one-hand weapon may go in either hand)
local WORN = {
  [1] = { 1 }, [2] = { 2 }, [3] = { 3 }, [4] = { 4 }, [5] = { 5 }, [20] = { 5 }, [6] = { 6 }, [7] = { 7 }, [8] = { 8 },
  [9] = { 9 }, [10] = { 10 }, [11] = { 11, 12 }, [12] = { 13, 14 }, [13] = { 16, 17 }, [14] = { 17 }, [15] = { 18 },
  [16] = { 15 }, [17] = { 16 }, [19] = { 19 }, [21] = { 16 }, [22] = { 17 }, [23] = { 17 }, [25] = { 18 }, [26] = { 18 }, [28] = { 18 },
}
local WORN_NAME = { INVTYPE_HEAD = 1, INVTYPE_NECK = 2, INVTYPE_SHOULDER = 3, INVTYPE_BODY = 4, INVTYPE_CHEST = 5, INVTYPE_ROBE = 20,
  INVTYPE_WAIST = 6, INVTYPE_LEGS = 7, INVTYPE_FEET = 8, INVTYPE_WRIST = 9, INVTYPE_HAND = 10, INVTYPE_FINGER = 11,
  INVTYPE_TRINKET = 12, INVTYPE_WEAPON = 13, INVTYPE_SHIELD = 14, INVTYPE_RANGED = 15, INVTYPE_CLOAK = 16, INVTYPE_2HWEAPON = 17,
  INVTYPE_TABARD = 19, INVTYPE_WEAPONMAINHAND = 21, INVTYPE_WEAPONOFFHAND = 22, INVTYPE_HOLDABLE = 23, INVTYPE_THROWN = 25,
  INVTYPE_RANGEDRIGHT = 26, INVTYPE_RELIC = 28 }
--- the character slots an item goes in ({} for something you don't wear, like a token)
function LR.wornIn(id)
  local it = LR.ITEMS[id]
  local kind = it and it[3]
  if not kind and C_Item and C_Item.GetItemInfoInstant then
    local _, _, _, loc = C_Item.GetItemInfoInstant(id)
    kind = WORN_NAME[loc or ""]
  end
  return WORN[kind or 0] or {}
end

--- an item's class and subclass numbers from the loot lists or the game (classes: 3 gem, 7 trade goods, 9 recipe,
--- 15 miscellaneous), or nil when it isn't known
function LR.itemClass(id)
  local it = LR.ITEMS[id]
  if it and it[4] then return it[4], it[5] end
  if C_Item and C_Item.GetItemInfoInstant then return select(6, C_Item.GetItemInfoInstant(id)) end
end

--- what goes on a session's loot list besides gear, mounts and recipes (the owner's list): marks, raid gems, the Karazhan
--- library's books and the like. Anything in the raid's own lists counts too (tier tokens, Magtheridon's Head).
LR.LISTED_LOOT = {
  [32897] = true,   -- Mark of the Illidari
  [32428] = true,   -- Heart of Darkness
  [32228] = true, [32231] = true, [32229] = true, [32249] = true, [32230] = true, [32227] = true,   -- Black Temple's epic gems
  [30183] = true,   -- Nether Vortex
  [29906] = true,   -- Vashj's Vial Remnant
  [34846] = true,   -- Black Sack of Gems
  [33933] = true, [33931] = true, [33932] = true, [33930] = true,   -- Amani Charms
  [33865] = true,   -- Amani Hex Stick
  [33993] = true,   -- Mojo
  [21882] = true,   -- Soul Essence
  [23865] = true, [23862] = true, [23864] = true, [23857] = true,   -- Wrath of the Titans, Redemption of the Fallen, Torment of
                                                                    -- the Worgen, Legacy of the Mountain King
}
--- whether a dropped item goes on the session's loot list: gear, mounts, recipes (plans, schematics, formulas, patterns,
--- designs), the raid's own loot and LR.LISTED_LOOT. Not cloth, trade goods, gems, potions, gold or anything else.
function LR.listedLoot(s, id)
  if LR.LISTED_LOOT[id] or LR.raidHas(s and s.raid, id) or #LR.wornIn(id) > 0 then return true end
  local class, sub = LR.itemClass(id)
  return class == 9 or (class == 15 and sub == 5)
end

--- loot to count, not to roll for (Nether Vortexes, Marks, Amani Charms): not in the session's raid's lists, not
--- worn, not a recipe, and below epic unless it's a trade good. The Loot tab lists these with how many dropped; they
--- aren't held for rolling out or trading.
function LR.minorLoot(s, id)
  if LR.raidHas(s and s.raid, id) or #LR.wornIn(id) > 0 then return false end
  local class = LR.itemClass(id)
  if class == 9 then return false end
  return LR.quality(id) < 4 or class == 7
end

local SLOT_NAME = {
  [1] = "Head", [2] = "Neck", [3] = "Shoulder", [5] = "Chest", [6] = "Waist", [7] = "Legs", [8] = "Feet", [9] = "Wrist",
  [10] = "Hands", [11] = "Finger", [12] = "Trinket", [13] = "One-Hand", [14] = "Off Hand", [15] = "Ranged", [16] = "Back",
  [17] = "Two-Hand", [20] = "Chest", [21] = "Main Hand", [22] = "Off Hand", [23] = "Held In Off-hand", [25] = "Thrown",
  [26] = "Ranged", [28] = "Relic",
}
local ARMOR_NAME = { [1] = "Cloth", [2] = "Leather", [3] = "Mail", [4] = "Plate", [6] = "Shield", [7] = "Libram", [8] = "Idol", [9] = "Totem" }
local WEAPON_NAME = { [0] = "Axe", [1] = "Axe", [2] = "Bow", [3] = "Gun", [4] = "Mace", [5] = "Mace", [6] = "Polearm", [7] = "Sword",
  [8] = "Sword", [10] = "Staff", [13] = "Fist Weapon", [15] = "Dagger", [16] = "Thrown", [18] = "Crossbow", [19] = "Wand" }
local MISC_NAME = { [9] = "Recipe", [7] = "Trade Goods", [3] = "Gem", [12] = "Quest", [15] = "Miscellaneous", [0] = "Consumable" }

local function info(id)
  if C_Item and C_Item.GetItemInfo then return C_Item.GetItemInfo(id) end
end

--- the item's name in the game's language once it's loaded (the English name until then)
function LR.itemName(id)
  local name = info(id)
  if name then return name end
  local it = LR.ITEMS[id]
  return it and it[1] or ("item " .. tostring(id))
end
function LR.quality(id)
  local it = LR.ITEMS[id]
  if it then return it[2] end
  local _, _, q = info(id)
  return q or 4
end
function LR.qualityHex(id) return QUALITY[LR.quality(id)] or "ffffff" end
function LR.coloredName(id) return "|cff" .. LR.qualityHex(id) .. LR.itemName(id) .. "|r" end
--- the game's link for chat ([Item] in its quality colour)
function LR.itemLink(id)
  local _, link = info(id)
  if link then return link end
  return ("|cff%s|Hitem:%d::::::::70:::::|h[%s]|h|r"):format(LR.qualityHex(id), id, LR.itemName(id))
end
function LR.itemIcon(id)
  local icon = C_Item and C_Item.GetItemIconByID and C_Item.GetItemIconByID(id)
  return icon or 134400                          -- the question mark
end
--- "Plate Hands", "Trinket", "Recipe" ...
function LR.itemKind(id)
  local it = LR.ITEMS[id]
  if not it then return "" end
  local slot, class, sub = SLOT_NAME[it[3]], it[4], it[5]
  if class == 4 then
    local a = ARMOR_NAME[sub]
    if a and (sub >= 6) then return a end
    if a and slot and slot ~= "Back" then return a .. " " .. slot end
    return slot or a or "Armor"
  end
  if class == 2 then
    local w = WEAPON_NAME[sub] or "Weapon"
    if slot == "Two-Hand" then return "Two-Hand " .. w end
    if slot and slot ~= "Ranged" and slot ~= "Thrown" then return slot .. " " .. w end
    return w
  end
  if class == 15 and LR.ITEMS[id][7] ~= -1 then return "Tier token" end
  if class == 15 and sub == 5 then return "Mount" end
  if class == 12 then return "Quest item" end
  return MISC_NAME[class] or ""
end

--- asks the game for every item of a raid so names and icons are ready
function LR.preload(key)
  local r = LR.RAID_BY_KEY[key]
  if not r or not (C_Item and C_Item.RequestLoadItemDataByID) then return end
  for _, id in ipairs(r.order) do
    if not info(id) then C_Item.RequestLoadItemDataByID(id) end
  end
end

--- finds a raid item from what someone typed: an item link, an item id, or (part of) its name. Returns the
--- id, or nil and a list of close matches; and the id that was linked, if one was. Names are searched in the
--- raid's loot and in `extra` (more item ids). Items for the other faction are skipped.
function LR.findItem(key, text, faction, extra)
  local r = LR.RAID_BY_KEY[key]
  text = U.trim(text)
  local linked = LR.idFrom(text)
  if linked then return (r and r.has[linked]) and linked or nil, {}, linked end
  local want = U.plain(text):gsub("^%[", ""):gsub("%]$", ""):lower()
  if want == "" then return nil, {} end
  local exact, partial, seen = {}, {}, {}
  local function consider(id)
    if seen[id] or not LR.forFaction(id, faction) then return end
    seen[id] = true
    local here, english = LR.itemName(id):lower(), (LR.ITEMS[id] and LR.ITEMS[id][1] or ""):lower()
    if here == want or english == want then
      exact[#exact + 1] = id
    elseif here:find(want, 1, true) or (english ~= "" and english:find(want, 1, true)) then
      partial[#partial + 1] = id
    end
  end
  for _, id in ipairs(r and r.order or {}) do consider(id) end
  for _, id in ipairs(extra or {}) do consider(id) end
  if #exact == 1 then return exact[1], {} end
  if #exact > 1 then return nil, exact end
  if #partial == 1 then return partial[1], {} end
  return nil, partial
end

--- items a session knows of besides its raid's loot: reserved, hard reserved, or seen dropping
function LR.sessionItems(s)
  local out, seen = {}, {}
  local function add(id) if type(id) == "number" and not seen[id] then seen[id] = true out[#out + 1] = id end end
  for _, r in pairs(s.res or {}) do for _, id in ipairs(r.i or {}) do add(id) end end
  for id in pairs(s.hr or {}) do add(id) end
  for _, d in ipairs(s.drops or {}) do add(d.i) end
  table.sort(out)
  return out
end

--- finds an item for a session: a link to anything the session allows, or a name from its raid's loot and
--- the items it knows of. Returns as LR.findItem.
function LR.findInSession(s, text, faction)
  local id, close, linked = LR.findItem(s.raid, text, faction, LR.sessionItems(s))
  if linked and LR.allowedItem(s, linked) then return linked, {} end
  return id, close, linked
end
