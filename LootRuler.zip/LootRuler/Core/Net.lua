-- Keeping everyone in step. The raid leader's addon holds the session that counts and sends a copy of it
-- (reserves and all) to the group, and to the guild when the leader shares it there, every time it
-- changes. Raiders' addons send the leader their own picks; the leader checks them against the rules and
-- answers. Players without the addon whisper the leader instead (Core/Whisper.lua).
--
-- Raiders can pick while the leader is offline or out of the group: their picks are kept and sent as soon
-- as the leader's addon is heard from again.
--
-- A private session (s.pv, LR.startPrivate) is mine alone: I lead it on my screen, but it's never sent, never answers
-- anyone and never says anything in chat. It only holds what it sees (the loot list, reserves I import). Closing it
-- forgets it, and joining someone's session (UI.joinPrompt) or opening my own closes it.
--
-- Messages (LibSerialize + LibDeflate over AceComm, prefix "LootRuler"):
--   T  leader -> group / guild    the whole session
--   U  leader -> group            what changed in it since the copy the group last had: { id, f = that copy's rev, r = the
--                                 new rev, c = S.diff }. Only when everyone in the group with LootRuler takes it (fl 8);
--                                 else, to the guild, by whisper and every SESSION_FULL_EVERY sends, the whole session.
--   E  leader -> group / guild    the session was ended
--   Q  anyone -> group / guild    "which sessions are open?" (leaders answer with T)
--   P  raider -> leader           my picks for session id: { c = class, i = items }
--   A  leader -> raider           the answer to P: ok, or why not, with the picks the leader now has
--   R, X, N                       rolling out loot (Core/Rolls.lua)
--   D                             the raid's drops (Core/Drops.lua)
--   V  anyone -> group            "I have LootRuler, this version" (on joining a group, and when asked)
-- Every message also says what the sender's addon can do (fl, bits added together): 1 = it can take over a session
-- (a new leader), 2 = it takes bids ahead on queued auctions (B, Core/Rolls.lua), 4 = it takes reserve swap requests (S, Core/Swap.lua),
-- 8 = it takes a session's changes (U).
-- Who sent a message is told by the game, so nobody can send picks in someone else's name or a session
-- for a leader who isn't them.
--
-- Older and newer versions work together. Every message says which version sent it (av). A version
-- ignores message types and fields it doesn't know, and keeps what it doesn't understand (a raid it
-- doesn't know, a kind of award it doesn't know) instead of throwing the whole thing away. A message only
-- an up-to-date version can handle says so (mv: the oldest protocol that understands it) and older
-- versions leave it alone. Changes should be new fields and new message types, never new meanings for old
-- ones; `v` stays 1 because the first release ignores anything with a higher one.
local _, LR = ...
local U, S = LR.U, LR.Session

local PROTOCOL = 1
LR.FEATURE_LEAD, LR.FEATURE_AHEAD, LR.FEATURE_SWAP, LR.FEATURE_CHANGES = 1, 2, 4, 8
local FEATURES = LR.FEATURE_LEAD + LR.FEATURE_AHEAD + LR.FEATURE_SWAP + LR.FEATURE_CHANGES   -- what this version can do, sent as fl (see the top)
local KEEP_DAYS = 7

local Net = {}
LR.Net = Net
local AceComm = LibStub("AceComm-3.0")
local LibSerialize = LibStub("LibSerialize")
local LibDeflate = LibStub("LibDeflate")
AceComm:Embed(Net)

local db              -- LootRulerDB (LR.DB_NAME): sessions, mine, current, settings
local listeners = {}

--- something changed that the window shows
function LR.changed(what)
  if what == "roster" and LR.rosterChanged then LR.rosterChanged() end
  for _, fn in ipairs(listeners) do fn(what) end
end
function LR.onChange(fn) listeners[#listeners + 1] = fn end

function LR.print(msg) print("|cffffd100" .. LR.TITLE .. "|r: " .. msg) end

--- every LootRuler sound goes through here: none when they're switched off (Settings: sounds), on the channel picked
--- (soundChannel); a window's own click sound (ui) stays on the game's effects channel
LR.SOUND_CHANNELS = { { "Master", "Main" }, { "SFX", "Effects" }, { "Dialog", "Dialog" }, { "Ambience", "Ambience" } }
function LR.sound(id, ui)
  if not db or not db.settings.sounds or not id then return end
  PlaySound(id, ui and "SFX" or db.settings.soundChannel)
end

---------------------------------------------------------------------- saved state
-- every option, and what it is until changed (the Settings tab, UI/Settings.lua)
LR.DEFAULTS = {
  theme = "classic",       -- how LootRuler's windows look (UI/Kit.lua, K.THEMES); a change comes in with a reload
  hideWhispers = true,     -- "!lr" messages (whispers and raid chat) and the answers don't show in my chat
  rollWindow = true,       -- roll windows pop up
  rollOnlyMine = false,    -- ...only for items I may roll on
  rollHideUnusable = false, -- ...not for items my class can't use (open to everyone)
  rollCloseAfter = false,  -- my roll window closes once I've rolled
  rollScale = 1,           -- how big roll windows are (UI.ROLL_SIZES)
  reservedAlert = true,    -- an item I reserved is rolled out: told on screen, with a sound (UI/RollFrame.lua)
  inspectGear = true,      -- running loot: the game's inspect shows what raiders wear (rolls, Core/Rolls.lua; Raid gear, Core/Overview.lua)
  sounds = true,           -- LootRuler's sounds (LR.sound)
  soundChannel = "Master", -- ...on this channel (LR.SOUND_CHANNELS)
  rollList = true,         -- roll windows list everyone's rolls that count, best first (UI/RollFrame.lua)
  tradeHelp = false,       -- won items go into trades with their winners
  tradeAnnounce = true,    -- when I'm running loot, the raid hears what I trade and to whom
  raidPrompt = true,       -- going into a different raid (or a new lockout) with a session open asks to start a new one (UI/Where.lua)
  tradeTimers = false,     -- a bar for each item I hold to roll out or trade, with the time left (UI/Timers.lua)
  tradeWarn = true,        -- items I'm holding: told when 15 and 5 minutes are left to trade them (Core/Drops.lua)
  announceLoot = true,     -- the loot master opens a corpse: its epics, and anything reserved, go in raid chat (Core/Drops.lua)
  autoTrade = false,       -- giving out an item that's in my bags opens a trade with the winner (Core/Drops.lua)
  exportTemplate = "{date};{player};{item};{how}",   -- my own export layout: a line for each item (Core/Export.lua)
  exportHeader = "",       -- ...and its first line
  rollSeconds = 20,        -- how long everyone has to roll
  confirmWinner = true,    -- the winner of a roll is said in raid chat when the loot master gives it out (Rolls.award)
  rollCountdown = true,    -- the end of a roll in raid chat ("You have 10 seconds to roll on...", then "5..." to "1...")
  batchSeconds = 60,       -- how long several auctions at once last (Core/Batch.lua)
  answerBagChecks = true,  -- tell whoever runs loot how many of the items they ask about I carry (Core/Bags.lua)
  rollKinds = {},          -- my own roll types for rolls open to everyone: { { n = "Transmog", hi = 98 } } (Core/Roll.lua)
  raidCommands = true,     -- "!lr" works in raid and party chat, not just by whisper
  raidWarning = true,      -- rolls are announced as raid warnings (leader or assistant), not plain raid chat
  recordGargul = true,     -- Gargul's "[item] was awarded to Ann" lines count as given out, for the leader (Core/Drops.lua)
  recordGroupWins = false, -- group loot: epics won with the game's Need / Greed count as given out (Core/Drops.lua)
  remindUnrecorded = true, -- the master looter gives an item out without LootRuler: asked whether to record it (UI/Master.lua)
  mlPrompt = true,         -- becoming the master looter: asked whether to open the loot master window and tell the raid
  mlAnnounce = false,      -- ...or the raid is told by itself (UI/Master.lua)
  outbidAlert = true,      -- someone bid more than me in an auction: told on screen, with a sound (UI/RollFrame.lua)
  finalCall = true,        -- running an auction: a final call in raid chat with 10 seconds left (Core/Rolls.lua)
  potAfterSale = true,     -- ...and the pot so far after each sale
  awardGuild = false,      -- who got what goes in guild chat too (Core/Rolls.lua)
  autoLoot = false,        -- the master looter's loot rules hand out what they match (Core/AutoLoot.lua)
  autoLootRules = {},      -- { { what, to } }, first match wins
  lootGold = false,        -- the master looter picks up a corpse's gold (Core/AutoLoot.lua)
  autoRollRules = {},      -- item id -> "pass" / "MS" / "OS": what my roll windows do on their own
  autoPassUnusable = false, -- pass on items my class can't use
  groupLoot = false,       -- the game's Need / Greed windows are rolled by my rules (Core/GroupLoot.lua)
  groupLootRules = {},     -- { { what, act } }, first match wins
  groupLootConfirm = false, -- ...and the game's "this item will bind to you" is answered yes for those rolls
  highlight = true,        -- the game's loot windows glow on items I reserved (UI/Highlight.lua)
  tooltipInfo = true,      -- item tooltips say who reserved the item
  lootTags = true,         -- the game's loot window marks reserved items with who reserved them (UI/Highlight.lua)
  gargulWindows = true,    -- Gargul's rolls get a roll window like LootRuler's, unless Gargul is loaded (Core/Rolls.lua)
  pickedUp = true,         -- a small note at the top of the screen when loot is picked up, with who reserved it (UI/PickedUp.lua)
  reserveStrip = true,     -- while an item is rolled for, a strip lists everyone who reserved it (UI/ReserveStrip.lua)
  remindOnJoin = false,    -- when I run reserves, people who join and haven't reserved are told how (Core/Whisper.lua)
  testTab = false,         -- the Test tab: pretend rolls and messages, only on my screen (UI/Test.lua)
  rollShortcut = "ctrlalt", -- clicking an item with these keys held rolls it out (UI/Shortcuts.lua)
}
--- settings checked like anything else saved: every option there with the right type, and rules that make sense
function LR.checkSettings(set)
  set = type(set) == "table" and set or {}
  for k, v in pairs(LR.DEFAULTS) do
    if set[k] == nil or type(set[k]) ~= type(v) then set[k] = type(v) == "table" and U.copy(v) or v end
  end
  set.autoLootRules = U.filter(set.autoLootRules, function(r)
    return type(r) == "table" and type(r.what) == "string" and type(r.to) == "string"
  end)
  for id, action in pairs(set.autoRollRules) do
    if type(id) ~= "number" or (action ~= "pass" and action ~= "MS" and action ~= "OS") then set.autoRollRules[id] = nil end
  end
  set.rollKinds = LR.Roll.checkKinds(set.rollKinds) or {}
  set.tradeSay = nil                 -- (a setting older versions had: trades said nearby out of a group)
  if set.rollScale < 0.5 or set.rollScale > 2 then set.rollScale = 1 end
  local okChannel = false
  for _, c in ipairs(LR.SOUND_CHANNELS) do if c[1] == set.soundChannel then okChannel = true end end
  if not okChannel then set.soundChannel = "Master" end
  set.groupLootRules = LR.GroupLoot.check(set.groupLootRules)
  if LR.K and LR.K.THEMES and not LR.K.THEMES[set.theme] then set.theme = "classic" end
  return set
end

function LR.loadDB()
  local saved = _G[LR.DB_NAME]
  local fresh = saved == nil
  if type(saved) ~= "table" then saved = {}; _G[LR.DB_NAME] = saved end
  db = saved
  db.sessions = type(db.sessions) == "table" and db.sessions or {}  -- id -> session (ours as leader, or the latest copy from its leader)
  db.mine = type(db.mine) == "table" and db.mine or {}              -- id -> { i = my picks, dirty = not yet confirmed by the leader }
  db.ui = type(db.ui) == "table" and db.ui or {}
  if fresh then db.ui.toured = false end            -- (a new player: the welcome tour, the first time they open it)
  db.settings = LR.checkSettings(db.settings)
  -- the look, before any window is made (every frame is made in it)
  if LR.K and LR.K.useTheme then LR.K.useTheme(db.settings.theme) LR.themeLoaded = db.settings.theme end
  -- settings saved under a name (UI/Welcome.lua): checked the same way
  db.profiles = type(db.profiles) == "table" and db.profiles or {}
  for name, set in pairs(db.profiles) do
    if type(name) ~= "string" or #name > 24 or type(set) ~= "table" then db.profiles[name] = nil else db.profiles[name] = LR.checkSettings(set) end
  end
  db.notes = LR.Notes.check(db.notes)        -- my item notes (Core/Notes.lua)
  db.wish = LR.Prio.checkWish(db.wish)       -- thatsmybis wishlists I brought in (Core/Prio.lua)
  -- guild books: checked like a message from another player
  db.guilds = type(db.guilds) == "table" and db.guilds or {}
  for g, book in pairs(db.guilds) do
    if type(g) ~= "string" then db.guilds[g] = nil
    elseif not LR.Book.validBook(book) then db.guilds[g] = LR.Book.repair(book, g) end      -- (keeps every good entry)
  end
  -- past raids: checked like a session from someone else
  db.history = type(db.history) == "table" and U.filter(db.history, function(e) return LR.History.valid(e) end) or {}
  LR.db = db
  -- forget sessions nobody has touched for a week (what they gave out goes to past raids)
  local cutoff = U.now() - KEEP_DAYS * 86400
  for id, s in pairs(db.sessions) do
    if not S.valid(s) or s.practice then db.sessions[id] = nil db.mine[id] = nil   -- (a practice raid isn't kept)
    elseif (s.updated or 0) < cutoff then
      if not s.pv then LR.History.archive(s, s.updated or U.now()) end      -- (a private one is just forgotten)
      db.sessions[id] = nil db.mine[id] = nil
    end
  end
  for id, m in pairs(db.mine) do
    local ok = db.sessions[id] and type(m) == "table" and type(m.i) == "table" and #m.i <= S.MAX_SR + S.MAX_EXTRA
    if ok then for _, item in ipairs(m.i) do if type(item) ~= "number" then ok = false end end end
    if not ok then db.mine[id] = nil end
  end
  if db.current and not db.sessions[db.current] then db.current = nil end
  LR.db = db
  return db
end

function LR.session(id) return id and db.sessions[id] end
function LR.isLeader(s) return s ~= nil and U.samePlayer(s.leader, U.me()) end
function LR.myClass() local _, c = UnitClass("player") return c end

--- the session the window shows: the chosen one, else the newest open one whose leader is in the group or is us
--- sessions someone in the group runs that I said no to ("Join their reserves?"): id -> true
local function declined()
  if type(db.ui.declined) ~= "table" then db.ui.declined = {} end
  return db.ui.declined
end
--- whether a session shows by itself, without asking: mine, or run by the group's leader or master looter
function LR.showsBySelf(s)
  return LR.isLeader(s) or (LR.inGroup(s.leader) and LR.groupBoss(s.leader) and not declined()[s.id])
end
function LR.current()
  if db.current and db.sessions[db.current] then return db.sessions[db.current] end
  local best
  for _, s in pairs(db.sessions) do
    if not s.ended and LR.showsBySelf(s) and (not best or s.created > best.created) then best = s end
  end
  return best
end
--- I said no to joining a session (it's still kept, and can be picked from the session list)
function LR.decline(id) declined()[id] = true if db.current == id then db.current = nil end LR.changed("select") end
function LR.select(id) db.current = id LR.changed("select") end

--- every known session, newest first
function LR.sessions()
  local out = {}
  for _, s in pairs(db.sessions) do out[#out + 1] = s end
  table.sort(out, function(a, b) return a.created > b.created end)
  return out
end

--- my picks in a session: as the leader has them, or as I've picked them and the leader hasn't confirmed yet
function LR.myPicks(s)
  if not s then return {} end
  local mine = db.mine[s.id]
  if not LR.isLeader(s) and mine and mine.dirty then return mine.i end
  return S.reservesOf(s, U.me())
end
function LR.pending(s) local m = s and db.mine[s.id] return m ~= nil and m.dirty == true end

---------------------------------------------------------------------- the group
function LR.groupChannel()
  if LR.Practice.on then return "RAID" end              -- (a practice raid: shown, never said; Core/Practice.lua)
  if IsInRaid() then return "RAID" end
  if IsInGroup() then return "PARTY" end
end

--- group members: { name = "Name-Realm", class = "PALADIN", online = bool, leader = bool, assist = bool }
--- The group is read from the game once and kept until it changes (the roster events below, a practice raid starting or
--- ending, or KEEP_ROSTER seconds at most), with an index by name for LR.inGroup.
local rosterKept, rosterByName, rosterAt
local KEEP_ROSTER = 10
function LR.rosterChanged() rosterKept, rosterByName, rosterAt = nil, nil, nil end
local function readRoster()
  local out = {}
  if IsInRaid() then
    for i = 1, GetNumGroupMembers() do
      local name, rank, _, _, _, class, _, online = GetRaidRosterInfo(i)
      if name then out[#out + 1] = { name = U.full(name), class = class, online = online and true or false, leader = rank == 2, assist = rank == 1 } end
    end
  else
    local units = { "player" }
    if IsInGroup() then for i = 1, GetNumGroupMembers() - 1 do units[#units + 1] = "party" .. i end end
    for _, unit in ipairs(units) do
      if UnitExists(unit) then
        local name, realm = UnitName(unit)
        local _, class = UnitClass(unit)
        out[#out + 1] = { name = realm and realm ~= "" and (name .. "-" .. realm) or U.full(name), class = class,
          online = UnitIsConnected(unit) and true or false, leader = UnitIsGroupLeader(unit) and true or false,
          assist = UnitIsGroupAssistant(unit) and true or false }
      end
    end
  end
  if LR.Practice.on then
    out[1].leader = true
    for _, m in ipairs(LR.Practice.roster()) do out[#out + 1] = m end
  end
  return out
end
local function keptRoster()
  if rosterKept and GetTime() - rosterAt < KEEP_ROSTER then return rosterKept, rosterByName end
  local list, byName = readRoster(), {}
  for _, m in ipairs(list) do byName[U.foldCase(m.name)] = m end
  -- (someone the game hasn't loaded yet has no name: read again next time rather than keep a short list)
  local whole = not IsInGroup() or LR.Practice.on or #list >= GetNumGroupMembers()
  if whole then rosterKept, rosterByName, rosterAt = list, byName, GetTime() end
  return list, byName
end
--- the group (a new list each time, so it can be sorted or added to; the members in it are shared: don't change them)
function LR.roster()
  local list = keptRoster()
  local out = {}
  for i, m in ipairs(list) do out[i] = m end
  return out
end
--- the unit ("raid3", "party1", "player") of someone in the group, for the game's functions that take one; nil if not
function LR.unitOf(name)
  if not name then return nil end
  if U.samePlayer(name, U.me()) then return "player" end
  local units = {}
  if IsInRaid() then for i = 1, GetNumGroupMembers() do units[#units + 1] = "raid" .. i end
  elseif IsInGroup() then for i = 1, GetNumGroupMembers() - 1 do units[#units + 1] = "party" .. i end end
  for _, u in ipairs(units) do
    local n, r = UnitName(u)
    if n and U.samePlayer((r and r ~= "") and (n .. "-" .. r) or n, name) then return u end
  end
end
function LR.inGroup(name)
  if not name or not (IsInGroup() or LR.Practice.on) then return false end
  local _, byName = keptRoster()
  return byName[U.foldCase(U.full(name))] or false
end
function LR.classOf(name)
  local m = LR.inGroup(name)
  return m and m.class or nil
end

---------------------------------------------------------------------- sending
local function encode(msg)
  msg.v = 1                                         -- see the top: never raised
  msg.av = LR.VERSION
  msg.fl = FEATURES
  return LibDeflate:EncodeForWoWAddonChannel(LibDeflate:CompressDeflate(LibSerialize:Serialize(msg)))
end
local function decode(text)
  local raw = LibDeflate:DecodeForWoWAddonChannel(text)
  raw = raw and LibDeflate:DecompressDeflate(raw)
  if not raw then return nil end
  local ok, msg = LibSerialize:Deserialize(raw)
  if ok and type(msg) == "table" and type(msg.t) == "string" then return msg end
end
Net.encode, Net.decode = encode, decode

local function send(msg, channel, target)
  if not channel or LR.Practice.on then return end      -- (nothing is sent during a practice raid)
  Net:SendCommMessage(LR.PREFIX, encode(msg), channel, target, "NORMAL")
end
Net.send = send

--- sends the newest state of something (a session, a batch of auctions): name says which, build()
--- makes the message when it goes. While one is still going out on a channel (a long one goes in parts, a few a
--- second), newer ones wait, and only the newest goes next: an out-of-date one is never sent. Everything goes at
--- the same priority: raiders' addons put a long message back together by sender and channel, so the parts of two
--- long messages mustn't take turns.
local newestOut, newestNext = {}, {}           -- key -> when the one going out started; -> what makes the next one
local NEWEST_OUT_MAX = 30                      -- (seconds: one that never says it's done stops holding the others)
local function sendNewest(name, build, channel, target)
  if not channel or LR.Practice.on then return end
  local key = name .. "|" .. channel .. "|" .. (target or "")
  if newestOut[key] and GetTime() - newestOut[key] < NEWEST_OUT_MAX then
    -- (waits for the one going out; if that never says it's done, it goes anyway once that one is too old to wait for)
    if not newestNext[key] then
      local started = newestOut[key]
      C_Timer.After(NEWEST_OUT_MAX - (GetTime() - started) + 0.1, function()
        if newestOut[key] == started and newestNext[key] then
          local nxt = newestNext[key]
          newestOut[key], newestNext[key] = nil, nil
          sendNewest(name, nxt, channel, target)
        end
      end)
    end
    newestNext[key] = build
    return
  end
  newestOut[key], newestNext[key] = GetTime(), nil
  Net:SendCommMessage(LR.PREFIX, encode(build()), channel, target, "NORMAL", function(_, sent, total)
    if sent < total then return end
    newestOut[key] = nil
    local nxt = newestNext[key]
    if nxt then newestNext[key] = nil sendNewest(name, nxt, channel, target) end
  end)
end
Net.sendNewest = sendNewest
--- a copy of a session: to the group, only what changed since the copy it last had (U), when everyone in it with
--- LootRuler takes that; else the whole session (T). The changes are worked out when it goes, so a change that waited
--- behind another still goes with everything since.
local SESSION_FULL_EVERY = 25                  -- a whole copy every so often, so a raider who missed something catches up
local groupSent = {}                           -- session id .. "|" .. channel -> { copy = what the group has, n = changes since a whole one }
local function everyoneTakesChanges()
  for _, m in ipairs(LR.roster()) do
    if not U.samePlayer(m.name, U.me()) and LR.versionOf(m.name) and not LR.hasFeature(m.name, LR.FEATURE_CHANGES) then return false end
  end
  return true
end
Net.everyoneTakesChanges = everyoneTakesChanges
local function sendSession(s, channel, target)
  local group = (channel == "RAID" or channel == "PARTY") and not target
  sendNewest("T:" .. s.id, function()
    local key = s.id .. "|" .. channel
    local last = group and groupSent[key]
    -- (a new leader, or one handing it on, sends it whole: raiders take changes only from the leader they know)
    -- (a change that didn't move the version would be ignored by everyone: it moves now, before it goes)
    if last and last.copy.rev == s.rev and LR.isLeader(s) and S.diff(last.copy, s) then S.bump(s, U.now()) end
    if last and last.n < SESSION_FULL_EVERY and U.samePlayer(last.copy.leader, s.leader) and not s.next and everyoneTakesChanges() then
      local msg = { t = "U", id = s.id, f = last.copy.rev, r = s.rev, c = S.diff(last.copy, s) or {} }
      groupSent[key] = { copy = U.copy(s), n = last.n + 1 }
      return msg
    end
    if group then groupSent[key] = { copy = U.copy(s), n = 0 } end
    return { t = "T", s = s }
  end, channel, target)
end
Net.sendSession = sendSession

--- says something in chat (raid, party, a whisper...). It goes through ChatThrottleLib, which spaces lines
--- out when there are many (answering a whole raid's "!lr"s at once would otherwise get you muted for spam).
function LR.say(text, channel, target)
  if not channel then return end
  if LR.Practice.on then LR.Practice.show(text, channel, target) return end
  if ChatThrottleLib and ChatThrottleLib.SendChatMessage then
    ChatThrottleLib:SendChatMessage("NORMAL", LR.PREFIX, text, channel, nil, target)
  else
    local fn = (C_ChatInfo and C_ChatInfo.SendChatMessage) or SendChatMessage
    fn(text, channel, nil, target)
  end
end

--- where the leader's messages go: the group (if any) and the guild (when shared)
local function publishTo(s)
  local out = {}
  local g = LR.groupChannel()
  if g then out[#out + 1] = g end
  if s.guild and IsInGuild() then out[#out + 1] = "GUILD" end
  return out
end

--- how to reach a session's leader: a whisper when they're in our group and online, else the guild
--- channel when the session came from there; nil when they can't be reached right now
local function routeTo(s)
  local m = LR.inGroup(s.leader)
  if m and m.online then return "WHISPER", s.leader end
  if s.guild and IsInGuild() then return "GUILD" end
end

--- the leader sends the session out (once, shortly after a burst of changes). slow: a change nobody needs to see at once
--- (who's in a GDKP's pot): it goes out within SLOW_PUBLISH seconds, or with the next change, whichever is first.
--- In a group, the guild's copy is for guild members who aren't in it: it goes out at most every GUILD_EVERY seconds, and
--- not at all while every guild member online is in the group (they have the group's copy; one who logs in asks for it).
local publishSeq, publishWaiting, guildSent, guildWaiting = {}, {}, {}, {}
local SLOW_PUBLISH, GUILD_EVERY = 10, 30
Net.GUILD_EVERY = GUILD_EVERY
local function guildOutside()
  if (GetNumGuildMembers() or 0) == 0 then return true end    -- (the guild list isn't known yet: someone may be outside)
  return #LR.Guild.onlineOutside() > 0
end
local function sendGuild(s)
  if IsInGroup() and not guildOutside() then return end
  guildSent[s.id] = GetTime()
  sendSession(s, "GUILD")
end
local function toGuild(s)
  if not IsInGroup() or not guildSent[s.id] or GetTime() - guildSent[s.id] >= GUILD_EVERY then sendGuild(s) return end
  if guildWaiting[s.id] then return end                                  -- (one is on its way, and it'll be the newest)
  guildWaiting[s.id] = true
  C_Timer.After(GUILD_EVERY - (GetTime() - guildSent[s.id]), function()
    guildWaiting[s.id] = nil
    if LR.isLeader(s) and db.sessions[s.id] == s and s.guild and IsInGuild() then sendGuild(s) end
  end)
end
local groupHas = {}
function LR.publish(s, now, slow)
  if not LR.isLeader(s) or s.pv then return end         -- (a private session never leaves this computer)
  if slow and not now and publishWaiting[s.id] then return end           -- (one is on its way: it carries this too)
  publishSeq[s.id] = (publishSeq[s.id] or 0) + 1
  local mine = publishSeq[s.id]
  publishWaiting[s.id] = not now or nil
  local function go()
    if publishSeq[s.id] ~= mine then return end
    publishWaiting[s.id] = nil
    for _, ch in ipairs(publishTo(s)) do
      if ch == "GUILD" then toGuild(s) else sendSession(s, ch) if ch ~= "GUILD" then groupHas[s.id] = s.rev end end
    end
  end
  if now then go() else C_Timer.After(slow and SLOW_PUBLISH or 0.5, go) end
end
-- a change made with no group to send it to (say, reserves locking by themselves while logging in): it goes as soon as
-- there is one. groupHas: session id -> the version last sent to the group.
LR.onChange(function(what)
  if what ~= "roster" or not db or not LR.groupChannel() then return end
  for _, s in pairs(db.sessions) do
    if LR.isLeader(s) and not s.pv and not s.ended and not s.archived and (groupHas[s.id] or 0) ~= s.rev then LR.publish(s, nil, true) end
  end
end)

--- asks for open sessions
function LR.query()
  local g = LR.groupChannel()
  if g then send({ t = "Q" }, g) end
  if IsInGuild() then send({ t = "Q" }, "GUILD") end
end

--- sends my picks to the leader if they're waiting and the leader can be reached. The same picks aren't
--- sent again within a few seconds (group changes and the leader's updates both ask for a send).
local lastSent = {}
function LR.sendPicks(s, force)
  local mine = s and db.mine[s.id]
  if not mine or not mine.dirty or LR.isLeader(s) then return false end
  local channel, target = routeTo(s)
  if not channel then return false end
  local key = table.concat(mine.i, ",")
  local last = lastSent[s.id]
  if not force and last and last.key == key and GetTime() - last.at < 10 then return false end
  lastSent[s.id] = { key = key, at = GetTime() }
  send({ t = "P", id = s.id, c = LR.myClass(), i = mine.i }, channel, target)
  return true
end

---------------------------------------------------------------------- what the leader does
function LR.startSession(raidKey, sr, dupes, guild, name, any)
  LR.closePrivate()                                      -- (my own session for the raid: the private one isn't needed)
  local now = U.now()
  local s = S.new(U.me(), raidKey, sr, dupes, now, name, any)
  s.guild = guild and true or false
  s.go = true                  -- (only the group can reserve, until the leader says otherwise)
  s.br = S.okBrand(LR.db.ui.brand)   -- (the branding I used last)
  db.sessions[s.id] = s
  db.current = s.id
  S.saw(s, U.map(LR.roster(), function(m) return m.name end), now)       -- (who came: Core/History.lua's fairness)
  LR.preload(raidKey)
  LR.publish(s, true)
  LR.changed("session")
  return s
end

--- my private session (the one open, or nil): see the top
function LR.privateSession()
  for _, s in pairs(db.sessions) do if s.pv and LR.isLeader(s) then return s end end
end
--- opens a private session: it only holds what it sees (the loot list from loot lines and Gargul's awards, reserves I
--- import). Never sent or said anywhere. One at a time: a new one replaces the old.
function LR.startPrivate(raidKey, sr, dupes, name, any)
  LR.closePrivate()
  local now = U.now()
  local s = S.new(U.me(), raidKey, sr, dupes, now, name, any)
  s.id = s.id .. ":private"          -- (never the same as a session I open for the raid in the same second)
  s.pv = true
  s.guild = false
  db.sessions[s.id] = s
  db.current = s.id
  LR.preload(raidKey)
  LR.changed("session")
  return s
end
--- closes my private session: everything in it is forgotten (it isn't kept as a past raid)
function LR.closePrivate()
  local s = LR.privateSession()
  if not s then return false end
  db.sessions[s.id] = nil
  db.mine[s.id] = nil
  if db.current == s.id then db.current = nil end
  LR.changed("session")
  return true
end

-- who came: the leader's session notes everyone who's in the group while it runs (the fairness history)
LR.onChange(function(what)
  if what ~= "roster" or not db then return end
  local s = LR.current()
  if s and LR.isLeader(s) and not s.archived and (IsInGroup() or LR.Practice.on) then
    -- (raiders don't need it now: it goes out with the next change to the session)
    if S.saw(s, U.map(LR.roster(), function(m) return m.name end), U.now()) then s.updated = U.now() LR.changed("session") end
  end
end)

--- a change the leader made: save, tell everyone, redraw
local function leaderChanged(s)
  s.updated = U.now()
  LR.publish(s)
  LR.changed("session")
end
LR.leaderChanged = leaderChanged

function LR.configure(s, sr, dupes)
  local ok, touched = S.configure(s, sr, dupes, U.now())
  if ok then leaderChanged(s) end
  return ok, touched
end
function LR.setHR(s, id, forWho, note)
  local ok, lost = S.setHR(s, id, forWho, note, U.now())
  if ok then
    leaderChanged(s)
    if #lost > 0 then
      LR.print(("%s is now hard reserved; %s lost their reserve on it."):format(LR.itemLink(id), table.concat(U.map(lost, U.short), ", ")))
    end
  end
  return ok, lost
end
function LR.clearHR(s, id) if S.clearHR(s, id, U.now()) then leaderChanged(s) end end
--- locks or unlocks the reserves; the raid hears it either way (by hand or by itself), with how to swap or reserve
function LR.setLocked(s, locked)
  if S.setLocked(s, locked, U.now()) then
    leaderChanged(s)
    if locked and LR.Gargul.available() then LR.Gargul.send(s, true) end
    local ch = not s.pv and LR.groupChannel()
    if ch then
      local line = locked and ("Soft reserves are locked now. " .. LR.Whisper.swapHowTo())
        or ("Soft reserves are open again. " .. LR.Whisper.howTo())
      for _, l in ipairs(U.chatLines(LR.TAG .. " " .. line)) do LR.say(l, ch) end
    end
  end
end
--- who disenchants; the group hears who it is (or that there's nobody now)
function LR.setDisenchanter(s, player)
  if not S.setDisenchanter(s, player, U.now()) then return end
  leaderChanged(s)
  local ch = LR.groupChannel()
  if not ch or s.pv then return end
  LR.say(LR.TAG .. " " .. (s.de and ("%s is the disenchanter: items nobody wants go to them."):format(U.short(s.de))
    or "Nobody is the disenchanter now."), ch)
end
function LR.setPlusOne(s, on) if S.setPlusOne(s, on, U.now()) then leaderChanged(s) end end
function LR.setBench(s, list) if LR.isLeader(s) and S.setBench(s, list, U.now()) then leaderChanged(s) end end
function LR.setAutoLock(s, at) if S.setAutoLock(s, at, U.now()) then leaderChanged(s) end end
function LR.setOneWin(s, on) if S.setOneWin(s, on, U.now()) then leaderChanged(s) end end
function LR.setSessionBoost(s, on) if S.setBoost(s, on, U.now()) then leaderChanged(s) end end
function LR.setExtra(s, player, n)
  if not LR.isLeader(s) then return false end
  local ok, lost = S.setExtra(s, player, n, U.now())
  if ok then leaderChanged(s) end
  return ok, lost
end
--- +1s brought in (from Gargul, say): everyone's set, and the +1 rule switched on
function LR.importPlusOnes(s, list)
  if not LR.isLeader(s) then return false end
  local n = 0
  for _, x in ipairs(list) do if S.setPlusOnes(s, x.p, x.n, U.now()) then n = n + 1 end end
  S.setPlusOne(s, true, U.now())
  leaderChanged(s)
  return n
end
function LR.setSessionPrio(s, mode) if S.setPrio(s, mode, U.now()) then leaderChanged(s) end end
-- GDKP (Core/Gdkp.lua): only the leader's changes count
local function gdkp(fn)
  return function(s, ...)
    if not (LR.isLeader(s) and fn(s, ...)) then return false end
    -- a past raid (finishing its payouts): kept, not sent to anyone
    if s.archived then s.updated = U.now() LR.changed("history") else leaderChanged(s) end
    return true
  end
end
LR.setGdkp = gdkp(function(s, on, now)
  local changed = LR.Gdkp.set(s, on, U.now())
  if s.gdkp then LR.Gdkp.saw(s, U.map(LR.roster(), function(m) return m.name end), U.now()) end
  return changed
end)
LR.gdkpOption = gdkp(function(s, key, value) return LR.Gdkp.option(s, key, value, U.now()) end)
LR.gdkpStrict = gdkp(function(s, on) return LR.Gdkp.setStrict(s, on, U.now()) end)
LR.gdkpNoBids = gdkp(function(s, player, on) return LR.Gdkp.setNoBids(s, player, on, U.now()) end)
LR.gdkpRoleCut = gdkp(function(s, role, pct) return LR.Gdkp.setRoleCut(s, role, pct, U.now()) end)
LR.gdkpRole = gdkp(function(s, player, role) return LR.Gdkp.setRole(s, player, role, U.now()) end)
LR.gdkpPrice = gdkp(function(s, id, gold) return LR.Gdkp.setPrice(s, id, gold, U.now()) end)
LR.gdkpBonus = gdkp(function(s, player, gold) return LR.Gdkp.setBonus(s, player, gold, U.now()) end)
LR.gdkpOut = gdkp(function(s, player, out) return LR.Gdkp.setOut(s, player, out, U.now()) end)
LR.gdkpPaid = gdkp(function(s, player, gold, how) return LR.Gdkp.paid(s, player, gold, U.now(), how) end)
LR.gdkpAddGold = gdkp(function(s, gold, what) return LR.Gdkp.addGold(s, gold, what, U.now()) end)
LR.gdkpRemoveAdd = gdkp(function(s, index) return LR.Gdkp.removeAdd(s, index, U.now()) end)
LR.gdkpFixed = gdkp(function(s, player, gold) return LR.Gdkp.setFixed(s, player, gold, U.now()) end)
LR.gdkpFixedAll = gdkp(function(s, list) LR.Gdkp.setFixedAll(s, list, U.now()) return true end)
LR.gdkpSalePrice = gdkp(function(s, index, gold) return LR.Gdkp.setSalePrice(s, index, gold, U.now()) end)
LR.gdkpPrices = gdkp(function(s, prices) return LR.Gdkp.setPrices(s, prices, U.now()) > 0 end)
-- the organiser's own pot rules
LR.gdkpAddRule = gdkp(function(s, name) return LR.Gdkp.addRule(s, name, U.now()) ~= nil end)
LR.gdkpEditRule = gdkp(function(s, index, fields) return LR.Gdkp.editRule(s, index, fields, U.now()) end)
LR.gdkpRemoveRule = gdkp(function(s, index) return LR.Gdkp.removeRule(s, index, U.now()) end)
LR.gdkpRuleTo = gdkp(function(s, index, player, on) return LR.Gdkp.ruleTo(s, index, player, on, U.now()) end)
function LR.adjustPlusOne(s, player, delta) if LR.isLeader(s) and S.adjustPlusOne(s, player, delta, U.now()) then leaderChanged(s) return true end return false end
function LR.setAny(s, any) if S.setAny(s, any, U.now()) then leaderChanged(s) end end
function LR.setGroupOnly(s, on) if LR.isLeader(s) and S.setGroupOnly(s, on, U.now()) then leaderChanged(s) end end
--- clears the reserves of everyone not in the group (offline members count as in it); returns the names
function LR.clearAbsent(s)
  if not LR.isLeader(s) or not (IsInGroup() or LR.Practice.on) then return {} end
  local cleared = S.clearAbsent(s, function(name) return LR.inGroup(name) ~= false or U.samePlayer(name, U.me()) end, U.now())
  if #cleared > 0 then leaderChanged(s) end
  return cleared
end
--- who has reserves but isn't in the group
function LR.absent(s)
  if not (IsInGroup() or LR.Practice.on) then return {} end
  return S.absent(s, function(name) return LR.inGroup(name) ~= false or U.samePlayer(name, U.me()) end)
end
--- the loot council (Core/Council.lua): names, or nil for none
function LR.setCouncil(s, names)
  if not LR.isLeader(s) then return false end
  if LR.Council.set(s, names, U.now()) then leaderChanged(s) end
  return true
end
--- the organiser's branding (Core/Session.lua): kept for their next session too
function LR.setBrand(s, br)
  if not LR.isLeader(s) then return false end
  br = S.okBrand(br)
  LR.db.ui.brand = br and U.copy(br) or nil
  if S.setBrand(s, br, U.now()) then leaderChanged(s) end
  return true
end
--- the session's softres.it page: set it (the leader; false when it isn't a softres.it link), and post it in raid chat
function LR.setLink(s, url)
  if not LR.isLeader(s) then return false end
  local t = U.trim(url or "")
  if t ~= "" and not S.okLink(t) then return false end
  if S.setLink(s, t, U.now()) then leaderChanged(s) end
  return true
end
function LR.postLink(s)
  local ch = LR.groupChannel()
  if not s.url or not ch or s.pv then return false end
  LR.say(("%s Reserve on softres.it: %s"):format(LR.TAG, s.url), ch)
  return true
end
function LR.setGuild(s, guild)
  s.guild = guild and true or false
  leaderChanged(s)
end
function LR.leaderAdd(s, player, class, id) local ok, why = S.add(s, player, class, id, true, U.now()) if ok then leaderChanged(s) end return ok, why end
function LR.removeDrop(s, k) if LR.isLeader(s) and S.removeDrop(s, k, U.now()) then leaderChanged(s) return true end return false end
function LR.unaward(s, index) if LR.isLeader(s) and S.unaward(s, index, U.now()) then leaderChanged(s) return true end return false end
--- changes an award (the leader) and tells the raid
local HOW = { SR = "their reserve", MS = "main spec", OS = "off spec", DE = "to disenchant" }
function LR.editAward(s, index, player, kind)
  local w = s.won and s.won[index]
  local was = w and w.p
  if not LR.isLeader(s) or not S.editAward(s, index, player, kind, U.now()) then return false end
  leaderChanged(s)
  if s.pv then return true end                           -- (a private session says nothing)
  local link = LR.itemLink(w.i)
  local line = U.samePlayer(was, w.p) and ("Changed: %s is %s's for %s."):format(link, U.short(w.p), HOW[kind])
    or ("Changed: %s is %s's (%s), not %s's."):format(link, U.short(w.p), HOW[kind], U.short(was))
  LR.Rolls.say(line)
  return true
end
function LR.leaderRemove(s, player, id) local ok, why = S.remove(s, player, id, true, U.now()) if ok then leaderChanged(s) end return ok, why end

---------------------------------------------------------------------- a new leader for a session
--- the session's leader is away: we're in a group, and they're not in it or are offline
function LR.leaderGone(s)
  if not s or not IsInGroup() then return false end
  local m = LR.inGroup(s.leader)
  return not m or not m.online
end
--- someone leads the group, or is its master looter (the game says so); assistants don't count
function LR.groupBoss(name)
  local m = LR.inGroup(name)
  if not m then return false end
  if m.leader then return true end
  local ml = LR.masterLooter()
  return ml ~= nil and U.samePlayer(ml, name)
end
--- whether I may take over a session: its leader is away, and I lead the group or am its master looter
function LR.mayTakeOver(s) return s ~= nil and not LR.isLeader(s) and not s.archived and LR.leaderGone(s) and LR.groupBoss(U.me()) end

local function tellGroup(text)
  local ch = LR.groupChannel()
  if ch then for _, line in ipairs(U.chatLines(LR.TAG .. " " .. text)) do LR.say(line, ch) end end
end
--- I run the reserves from now on: the raid hears who to whisper
local function nowMine(s, from, quiet)
  S.newLeader(s, U.me(), U.now())
  -- my own picks the old leader hadn't confirmed yet go in now (as the leader's do)
  local mine = db.mine[s.id]
  if mine and mine.dirty then S.set(s, U.me(), LR.myClass(), mine.i, true, U.now()) end
  db.mine[s.id] = nil
  db.current = s.id
  leaderChanged(s)
  if quiet then return end
  tellGroup(("%s runs the soft reserves now (taking over from %s). Whisper %s \"!reserve [item]\" to reserve or check yours."):format(
    U.short(U.me()), U.short(from), U.short(U.me())))
end
--- takes over a session whose leader is gone (I lead the group or am its master looter). Returns true, or false and why not.
function LR.takeOver(s)
  if not LR.mayTakeOver(s) then return false, "Only the raid leader or the master looter can take over, while the reserves' leader is away." end
  nowMine(s, s.leader)
  return true
end
--- takes over a session whose leader is gone, to hand it straight to someone else (the raid hears from them)
function LR.passOn(s, player)
  if not LR.canLead(player) then return false, ("%s's LootRuler can't take the reserves over (it's too old, or not there)."):format(U.short(player)) end
  if U.samePlayer(player, U.me()) then return LR.takeOver(s) end
  if not LR.mayTakeOver(s) then return false, "Only the raid leader or the master looter can take over, while the reserves' leader is away." end
  nowMine(s, s.leader, true)
  return LR.handOver(s, player)
end
--- the leader hands the session to someone in the group with LootRuler (their addon takes it on); nil takes it back
function LR.handOver(s, player)
  if not LR.isLeader(s) then return false, "Only the reserves' leader can hand them over." end
  if s.pv then return false, "A private session is only yours: it can't be handed over." end
  if player and not LR.canLead(player) then return false, ("%s's LootRuler can't take the reserves over (it's too old, or not there)."):format(U.short(player)) end
  if not S.handTo(s, player, U.now()) then return false end
  leaderChanged(s)
  return true
end
--- the session was handed to me: it's mine now
function LR.adopt(s)
  if not s.next or not U.samePlayer(s.next, U.me()) or LR.isLeader(s) then return end
  LR.print(("%s handed you the soft reserves: you run them now."):format(U.short(s.leader)))
  nowMine(s, s.leader)
end

-- the reserves' leader left the group: tell whoever may take over (the raid leader or master looter), once per session
local toldGone = {}
LR.onChange(function(what)
  if what ~= "roster" or not db then return end
  for id, s in pairs(db.sessions) do
    if LR.mayTakeOver(s) and not toldGone[id] and LR.inGroup(s.leader) == false then
      toldGone[id] = true
      LR.print(("%s, who runs the soft reserves, has left the group. Take them over on the Session tab (/lr)."):format(U.short(s.leader)))
    elseif not LR.leaderGone(s) then toldGone[id] = nil end
  end
end)

-- names from softres.it: someone joining (or reserving) may be who a name on the sheet really is (Core/Gargul.lua)
local recheckSoon = false
LR.onChange(function(what)
  if (what ~= "roster" and what ~= "session") or recheckSoon or not db then return end
  recheckSoon = true
  C_Timer.After(1, function()
    recheckSoon = false
    for _, s in pairs(db.sessions) do
      if s.sx and not s.archived and LR.isLeader(s) then
        for _, m in ipairs(LR.Gargul.recheck(s, LR.roster())) do
          LR.print(("%s on the softres.it sheet is %s: their reserves from the sheet count for them now."):format(U.short(m[1]), U.short(m[2])))
        end
      end
    end
  end)
end)
--- the leader puts a name from the sheet under the character it really is (Reserves tab, or after an import)
function LR.matchName(s, from, to)
  if not LR.isLeader(s) then return false end
  return LR.Gargul.rename(s, from, to, LR.classOf(to))
end

function LR.endSession(s)
  if s.practice then LR.Practice.stop() return end      -- (ending a practice raid's session ends the practice)
  if s.pv then if LR.isLeader(s) then LR.closePrivate() end return end   -- (a private one is forgotten, and nobody's told)
  if not LR.isLeader(s) then return end
  LR.History.archive(s, U.now())                -- what it gave out is kept under Past raids (Core/History.lua)
  for _, ch in ipairs(publishTo(s)) do send({ t = "E", id = s.id }, ch) end
  db.sessions[s.id] = nil
  db.mine[s.id] = nil
  if db.current == s.id then db.current = nil end
  LR.changed("session")
end

--- raiders forget a session (it stays with its leader, and comes back if they send it again)
function LR.forget(s)
  if not s or LR.isLeader(s) then return false end
  db.sessions[s.id] = nil
  db.mine[s.id] = nil
  if db.current == s.id then db.current = nil end
  LR.changed("session")
  return true
end

---------------------------------------------------------------------- what I do with my own reserves
--- reserve one more of an item in a session; returns true, or false and why
function LR.reserve(s, id) return LR.changeMine(s, function(items) items[#items + 1] = id end, id) end
function LR.unreserve(s, id)
  return LR.changeMine(s, function(items)
    local i = U.indexOf(items, id)
    if i then table.remove(items, i) end
  end, id)
end

function LR.changeMine(s, edit, id)
  if not s then return false, "NO_SESSION" end
  local me = U.me()
  if LR.isLeader(s) then
    local items = U.copy(S.reservesOf(s, me))
    edit(items)
    local ok, why = S.set(s, me, LR.myClass(), items, true, U.now())
    if ok then leaderChanged(s) end
    return ok, why
  end
  if s.locked then return false, "LOCKED" end
  local items = U.copy(LR.myPicks(s))
  local before = #items
  edit(items)
  -- only the group can reserve: outside it, I can take reserves back but not add (the leader's addon decides too)
  if #items > before and s.go and not LR.inGroup(s.leader) then return false, "GROUP_ONLY" end
  -- no reserves in a GDKP raid, or one that goes by priority lists only (taking them back is fine)
  if #items > before and s.gdkp then return false, "GDKP" end
  if #items > before and s.prio == "only" then return false, "PRIO_ONLY" end
  local ok, why = S.check(s, items, true, me)          -- which items are allowed is the leader's addon's call
  if not ok then return false, why end
  db.mine[s.id] = { i = items, dirty = true }
  LR.sendPicks(s, true)
  LR.changed("mine")
  return true
end

---------------------------------------------------------------------- receiving
local queryAnswered = {}

local handlers = {}
Net.handlers = handlers          -- Core/Rolls.lua adds the messages for rolling out loot

--- ours (I lead it), and a copy says it went on from me while I was away: one that changed hands after my last change, one
--- whose leader I never took it from (I just never heard: I made a change or two since, maybe), or one past mine. Only ever
--- asks the player (claims): LootRuler can't check it.
function Net.wentOnFromUs(known, t)
  if not S.ledBy(t, U.me()) then return false end
  if type(t.nl) == "number" and t.nl >= (known.updated or 0) then return true end
  return not S.ledBy(known, t.leader) or t.rev > known.rev
end

-- a session from its leader (a whole copy, T; or one put together from what changed, U)
local accept
function handlers.T(msg, channel, sender)
  local t = msg.s
  if not S.valid(t) then return end
  if not U.samePlayer(t.leader, sender) then
    -- a copy passed on by someone who isn't its leader counts only from the leader our copy names (it says they passed
    -- it on: we were away), or from whoever leads the group or is its master looter while that leader is gone (LR.askWho)
    local known = db.sessions[t.id]
    local relay = known and not U.samePlayer(known.leader, t.leader)
      and ((U.samePlayer(sender, known.leader) and S.ledBy(t, sender)) or LR.groupBoss(sender))
    if not relay then
      -- ours, and someone in the group says it went on from us while we were away (LR.tellStale): ask the raid leader and
      -- master looter, and the player decides (Session tab), as LootRuler can't check it
      if known and LR.isLeader(known) and not known.pv and not U.samePlayer(t.leader, U.me()) and S.ledBy(t, U.me()) and LR.inGroup(sender)
        and Net.wentOnFromUs(known, t) then
        LR.askWho(known)
        LR.noteClaim(known, t, sender)
      end
      return
    end
  end
  accept(t, channel, sender)
end

-- what changed in a session, from its leader: put in to our copy. A copy that isn't the one the changes are from (missed
-- one, or just came) asks the leader for the whole session (Q, by whisper: answered with T), once in a while at most.
local askedWhole = {}
--- our copy is behind one that exists (the sender's, at version r): ask the sender for the whole copy, by whisper, at most
--- every 10 seconds; if that has to wait, ask as soon as it may; and look again after each answer, so a copy never
--- stays behind just because nothing else changed since. Gives up after a few tries (the leader may be gone).
local catching = {}
function LR.catchUp(id, sender, r)
  local c = catching[id]
  if c then c.r, c.from = math.max(c.r, r), sender else c = { r = r, from = sender, n = 0 } catching[id] = c end
  local function ask()
    askedWhole[id] = GetTime()
    c.n = c.n + 1
    send({ t = "Q" }, "WHISPER", c.from)
  end
  local function done()
    local k = db and db.sessions[id]
    return catching[id] ~= c or c.n >= 4 or (k and (LR.isLeader(k) or (k.rev >= c.r and U.samePlayer(k.leader, c.from))))
  end
  -- now, when we may
  if not askedWhole[id] or GetTime() - askedWhole[id] > 10 then ask() end
  if c.timer then return end
  local function later()
    c.timer = nil
    if done() then if catching[id] == c then catching[id] = nil end return end
    local wait = askedWhole[id] and (askedWhole[id] + 10 - GetTime()) or 0
    if wait <= 0 then ask() wait = 12 end
    c.timer = true
    C_Timer.After(wait + 0.1, later)
  end
  c.timer = true
  C_Timer.After(math.max(0.1, (askedWhole[id] or 0) + 12 - GetTime()), later)
end
function handlers.U(msg, channel, sender)
  if type(msg.id) ~= "string" or type(msg.f) ~= "number" or type(msg.r) ~= "number" or type(msg.c) ~= "table" then return end
  local known = db.sessions[msg.id]
  -- (changes from someone who ran it before ours went on from them, made on a copy older than ours: they were away when it
  -- changed hands, and hear ours)
  if known and not U.samePlayer(known.leader, sender) and S.ledBy(known, sender) and msg.r < known.rev then LR.tellStale(known, sender) return end
  if known and (LR.isLeader(known) or known.rev >= msg.r) then return end
  -- (from someone who isn't its leader to us: a new leader, maybe. Their whole copy is checked like any. And changes
  -- only go onto the very copy they were made from: put onto a newer one, something added and taken back in between
  -- would stay in ours for good.)
  if not known or not U.samePlayer(known.leader, sender) or known.rev ~= msg.f or msg.c.leader or msg.c.id then
    LR.catchUp(msg.id, sender, msg.r)
    return
  end
  local t = S.patch(known, msg.c)
  if not t then return end
  t.rev = msg.r
  if not S.valid(t) or not U.samePlayer(t.leader, sender) then return end
  accept(t, channel, sender)
end

function accept(t, channel, sender)
  t.pv, t.practice = nil, nil       -- (only my own sessions are private or practice: never one that came from someone)
  local known = db.sessions[t.id]
  local claim = LR.claim(t.id)
  -- someone else leads it now: what I sent the group as its leader is out of date (if it comes back to me, it goes whole)
  for k in pairs(groupSent) do if k:sub(1, #t.id + 1) == t.id .. "|" then groupSent[k] = nil end end
  local tookOurs = false
  if known and not U.samePlayer(known.leader, t.leader) and S.ledBy(known, t.leader) and t.rev < known.rev then
    -- a copy from before it went on from someone who ran it then (they were away when it changed hands): never a change
    -- of hands, whoever they are now, as everything since would be lost. The sender hears ours.
    LR.tellStale(known, sender)
    return
  end
  if known and not U.samePlayer(known.leader, t.leader) then
    -- a new leader: only if it was handed to them, or they lead or assist the group and took it over while its
    -- leader was gone (or it was ours, and we were away). Anyone else claiming it is ignored.
    local vouched = U.samePlayer(sender, known.leader) and S.ledBy(t, sender)
    local later = type(t.nl) == "number" and t.nl >= (known.updated or 0)
    if not S.newLeaderOk(known, t.leader, LR.leaderGone(known), LR.groupBoss(sender), LR.isLeader(known), S.ledBy(t, U.me()), t.rev > known.rev,
      vouched, later) then
      -- someone else leads it now, by their copy: ask the leader we know (or, when they're gone or it's us, whoever leads
      -- the group or is its master looter) for theirs. Their word on who it went to counts; nobody else's does.
      LR.askWho(known)
      -- a copy that says it carried on from our leader, when nobody we trust can say so (our leader is away, or it's us):
      -- the player decides (Session tab), as LootRuler can't check it
      -- (ours: only one that changed hands after our copy's last change, as an old copy or a fork from before isn't a
      -- take-over. Someone else's: our leader is away, and whoever sends it runs it from in the group.)
      local claimed = U.samePlayer(t.leader, sender) and (
        (LR.isLeader(known) and LR.inGroup(sender) and Net.wentOnFromUs(known, t))
        or (not LR.isLeader(known) and LR.inGroup(sender) and (LR.leaderGone(known) or t.rev >= known.rev + S.EPOCH)))
      -- (a copy at least one change of hands past ours: it has changed hands since, whoever we last heard from)
      if claimed then
        LR.noteClaim(known, t, sender)
      end
      return
    end
    tookOurs = LR.isLeader(known)
    if tookOurs then LR.print(("%s runs the soft reserves now: they were taken over while you were away."):format(U.short(t.leader))) end
  elseif LR.isLeader(known) then return                     -- ours: we're the one that knows best
  elseif known and known.rev >= t.rev then
    LR.sendPicks(known, true)                               -- the leader is there: anything still waiting goes now
    return
  end
  local first = not known
  if claim and known and not U.samePlayer(known.leader, t.leader) then LR.dropClaim(t.id) end   -- (settled: a new leader we trust)
  local shown = first and LR.current()           -- (what I'm looking at before this one came)
  t.guild = t.guild or channel == "GUILD"
  db.sessions[t.id] = t
  local mine = db.mine[t.id]
  local theirs = S.reservesOf(t, U.me())
  if mine and mine.dirty then
    if U.sameItems(mine.i, theirs) then mine.dirty = false mine.i = U.copy(theirs)
    elseif not t.locked then LR.sendPicks(t, true)
    else db.mine[t.id] = { i = U.copy(theirs), dirty = false } end
  else
    db.mine[t.id] = { i = U.copy(theirs), dirty = false }
  end
  -- handed to me: my addon takes it on
  if t.next and U.samePlayer(t.next, U.me()) then LR.adopt(t) end
  -- it was ours, and we came back to find someone else runs it: the group hears it from us once, so anyone whose copy
  -- still names us (away when it changed hands, too) follows the new leader on our word
  if tookOurs and not LR.isLeader(t) and LR.groupChannel() then sendSession(t, LR.groupChannel()) end
  if first then
    LR.preload(t.raid)
    -- a new session from someone in our group: the group's leader's or master looter's shows by itself, unless I'm
    -- looking at someone else's that's open; anyone else's (or when I am) asks first, so nobody's window is taken over
    if LR.inGroup(t.leader) and not t.ended then
      local busy = shown and shown.id ~= t.id and not shown.ended and not U.samePlayer(shown.leader, t.leader)
      if LR.groupBoss(t.leader) and not busy then db.current = t.id
      elseif LR.UI and LR.UI.joinPrompt then LR.UI.joinPrompt(t) end
    end
    if not t.ended then
      LR.print(("%s opened soft reserves for %s%s: %s each%s. Type |cffffd100/lr|r to reserve."):format(
        U.short(t.leader), LR.raidOf(t).name, (t.br and t.br.n) and (" (" .. t.br.n .. ")") or "", U.plural(t.sr, "reserve"), t.dupes and "" or ", one per item"))
    end
  end
  LR.changed("session")
end

-- a session was ended by its leader
function handlers.E(msg, channel, sender)
  local s = db.sessions[msg.id]
  if not s or not U.samePlayer(s.leader, sender) or LR.isLeader(s) then return end
  LR.History.archive(s, U.now())
  db.sessions[msg.id] = nil
  db.mine[msg.id] = nil
  if db.current == msg.id then db.current = nil end
  LR.print(("%s closed the soft reserves for %s."):format(U.short(s.leader), LR.raidOf(s).name))
  LR.changed("session")
end

--- copies naming a new leader that LootRuler couldn't confirm (session id -> { t, from, leader }): shown on the Session tab
--- for the player to follow (or, for its leader, to let them run it). Kept in memory only.
local claims = {}
function LR.claim(id)
  local c, k = claims[id], db and db.sessions[id]
  -- (settled already; or ours has gone on from them since: theirs is an old copy now)
  if c and (not k or U.samePlayer(c.leader, k.leader) or (S.ledBy(k, c.leader) and c.t.rev < k.rev)) then claims[id] = nil return nil end
  return c
end
function LR.noteClaim(known, t, sender)
  local c = claims[known.id]
  local told = c and U.samePlayer(c.leader, t.leader)
  claims[known.id] = { t = U.copy(t), from = sender, leader = t.leader, was = known.leader }
  if told then return end
  if LR.isLeader(known) then
    LR.print(("%s says they took the soft reserves over from you while you were away. To let them run them, see the Session tab (/lr)."):format(U.short(t.leader)))
  else
    LR.print(("%s says they run the soft reserves now (%s, who ran them, is away and can't confirm it). To follow %s, see the Session tab (/lr)."):format(
      U.short(t.leader), U.short(known.leader), U.short(t.leader)))
  end
  LR.changed("session")
end
--- the player follows a claim (or, as its leader, lets the one claiming it run it): their copy replaces ours
function LR.followClaim(id)
  local c = claims[id]
  local known = db.sessions[id]
  claims[id] = nil
  if not c or not known or not S.valid(c.t) then return false end
  if U.samePlayer(c.leader, known.leader) then LR.changed("session") return not LR.isLeader(known) end   -- (already so)
  local was = known.next
  known.next = c.leader                                  -- (taken as handed to them: the player said so)
  accept(c.t, "WHISPER", c.from)
  if db.sessions[id] == known then known.next = was end  -- (not taken after all: ours stays as it was)
  -- the copy we kept may be a change or two old by now: ask them for theirs
  if not LR.isLeader(db.sessions[id]) then send({ t = "Q" }, "WHISPER", c.leader) end
  return not LR.isLeader(db.sessions[id])
end
--- the player keeps things as they are
function LR.dropClaim(id) claims[id] = nil LR.changed("session") end

--- our copy of a session names a leader who isn't leading it any more (a new leader's copy came): ask the leader we know
--- for theirs, by whisper (it says who they passed it to), or the group's leader and master looter when they're gone.
--- At most every 10 seconds for each session.
local askedWho = {}
--- someone our copy says led it before sent theirs, from before it changed hands: they hear ours (by whisper, at most every
--- 30 seconds), so they can follow on. Ours counts for them if it's from someone they trust (handlers.T); else they decide.
local toldStale = {}
function LR.tellStale(known, who)
  if known.pv or known.practice then return end
  local key = known.id .. "|" .. U.full(who)
  if toldStale[key] and GetTime() - toldStale[key] < 30 then return end
  toldStale[key] = GetTime()
  sendSession(known, "WHISPER", who)
end
function LR.askWho(known)
  local now = GetTime()
  if askedWho[known.id] and now - askedWho[known.id] < 10 then return end
  askedWho[known.id] = now
  local ask = {}
  local m = LR.inGroup(known.leader)
  if m and m.online and not LR.isLeader(known) then ask[1] = known.leader
  else
    for _, x in ipairs(LR.roster()) do if x.online and LR.groupBoss(x.name) and not U.samePlayer(x.name, U.me()) then ask[#ask + 1] = x.name end end
  end
  for _, who in ipairs(ask) do send({ t = "Q", id = known.id }, "WHISPER", who) end
end

-- someone asks which sessions are open: leaders answer (once every few seconds per channel), and everyone
-- in the group says they have the addon. Asked about one session (id: the asker's copy names a leader who isn't
-- leading it now), anyone who has it sends their copy: the asker decides whether to believe it.
function handlers.Q(msg, channel, sender)
  if type(msg.id) == "string" and channel == "WHISPER" then
    local s = db.sessions[msg.id]
    if s and not s.pv and not s.practice and not LR.isLeader(s) then
      local key = s.id .. sender .. "who"
      if not queryAnswered[key] or GetTime() - queryAnswered[key] > 5 then
        queryAnswered[key] = GetTime()
        sendSession(s, "WHISPER", sender)
      end
    end
  end
  -- the session goes to the one asking, by whisper: the rest of the raid or guild has it already (every version takes
  -- a session from its leader by whisper). Versions are still said to the group, once in a while: one message each
  -- instead of a whisper to every newcomer.
  if channel ~= "GUILD" then LR.hello(channel == "WHISPER" and sender or nil) end
  local now = GetTime()
  for _, s in pairs(db.sessions) do
    if LR.isLeader(s) and not s.pv and (channel ~= "GUILD" or s.guild) then
      local key = s.id .. sender
      if not queryAnswered[key] or now - queryAnswered[key] > 5 then
        queryAnswered[key] = now
        sendSession(s, "WHISPER", sender)
      end
    end
  end
end

-- a raider's picks, at the leader
function handlers.P(msg, channel, sender)
  local s = type(msg.id) == "string" and db.sessions[msg.id]
  if not s or not LR.isLeader(s) or s.pv or type(msg.i) ~= "table" then return end
  local items = {}
  for _, id in ipairs(msg.i) do if type(id) == "number" then items[#items + 1] = id end end
  local class = LR.classOf(sender) or (type(msg.c) == "string" and LR.CLASS_BIT[msg.c] and msg.c) or nil
  local rev = s.rev
  local ok, why, id = S.groupOk(s, sender, items, LR.inGroup(sender) and true or false)
  if ok then ok, why, id = S.set(s, sender, class, items, false, U.now()) end
  local answer = { t = "A", id = s.id, to = sender, ok = ok, why = why, item = id, i = S.reservesOf(s, sender) }
  local route, target = channel, nil
  if channel == "WHISPER" or LR.inGroup(sender) then route, target = "WHISPER", sender end
  send(answer, route, target)
  if s.rev ~= rev then leaderChanged(s) end
end

-- the leader's answer to my picks
function handlers.A(msg, channel, sender)
  if msg.to ~= nil and (type(msg.to) ~= "string" or not U.samePlayer(msg.to, U.me())) then return end
  local s = type(msg.id) == "string" and db.sessions[msg.id]
  if not s or not U.samePlayer(s.leader, sender) or type(msg.i) ~= "table" or #msg.i > S.MAX_SR + S.MAX_EXTRA then return end
  for _, id in ipairs(msg.i) do if type(id) ~= "number" then return end end
  if msg.item ~= nil and type(msg.item) ~= "number" then msg.item = nil end
  local before = db.mine[s.id] and db.mine[s.id].i or {}
  db.mine[s.id] = { i = U.copy(msg.i), dirty = false }
  -- keep our copy of the session in step until the next full copy arrives
  -- (the class as the leader has it, so our copy matches theirs)
  if #msg.i > 0 then s.res[U.me()] = { c = (s.res[U.me()] and s.res[U.me()].c) or LR.myClass(), i = U.copy(msg.i) } else s.res[U.me()] = nil end
  if not msg.ok then
    local why = S.WHY[msg.why] or "The leader didn't accept that."
    LR.print(("%s turned down your reserves: %s%s"):format(U.short(s.leader), why, msg.item and (" (" .. LR.itemLink(msg.item) .. ")") or ""))
    LR.toast(why)
  elseif not U.sameItems(before, msg.i) then
    LR.changed("mine")
  end
  LR.changed("mine")
end

function Net:OnComm(prefix, text, channel, sender)
  if prefix ~= LR.PREFIX or not sender then return end
  sender = U.full(sender)
  if U.samePlayer(sender, U.me()) then return end
  local msg = decode(text)
  if not msg or (msg.mv and (tonumber(msg.mv) or 0) > PROTOCOL) then return end
  LR.heardFrom(sender, msg.av, msg.fl)
  local fn = handlers[msg.t]
  if fn then
    local ok, err = pcall(fn, msg, channel, sender)
    if not ok then geterrorhandler()(err) end
  end
end

---------------------------------------------------------------------- who has the addon, which version
local versions = {}            -- "name-realm" (lower case) -> version string
local toldNewer = false

--- something came from a player's addon: remember its version; say once when there's a newer one
local features = {}          -- "name-realm" -> what their addon can do (fl)
function LR.heardFrom(sender, version, fl)
  if not sender then return end
  version = type(version) == "string" and version:sub(1, 20) or "1.0.0-beta"
  versions[U.full(sender):lower()] = version
  features[U.full(sender):lower()] = type(fl) == "number" and fl or 0
  if not toldNewer and U.compareVersions(LR.VERSION, version) < 0 then
    toldNewer = true
    LR.print(("%s has a newer LootRuler (%s; you have %s). It works with yours, but update when you can."):format(U.short(sender), version, LR.VERSION))
  end
  LR.changed("versions")
end

--- whether a player's LootRuler can take over a session (we've heard from it, and it's new enough)
function LR.hasFeature(name, bit)
  if U.samePlayer(name, U.me()) then return true end
  local fl = name and features[U.full(name):lower()] or 0
  return math.floor(fl / bit) % 2 == 1
end
function LR.canLead(name) return LR.hasFeature(name, LR.FEATURE_LEAD) end

--- the version of LootRuler a player has, if we've heard from them (and nil if not)
function LR.versionOf(name)
  if U.samePlayer(name, U.me()) then return LR.VERSION end
  return name and versions[U.full(name):lower()] or nil
end

--- my note on an item (Core/Notes.lua), or nil
function LR.noteFor(id) return db and db.notes and db.notes[id] or nil end
--- sets or (with no text) takes off my note on an item
function LR.setNote(id, text)
  if type(id) ~= "number" then return end
  db.notes[id] = LR.Notes.clean(text)
  LR.changed("notes")
end

--- who has an item on their thatsmybis wishlist, in order: { { p, n } }. here: only players in the group. Anyone who
--- has already been given it this session is left out.
function LR.wishFor(id, here)
  local list = db and db.wish and db.wish[id]
  if not list then return {} end
  local s = LR.current()
  local got, inGroup = {}, {}
  if s then for _, w in ipairs(LR.Session.winners(s, id)) do got[U.foldCase(U.bare(w[1]))] = true end end
  if here then for _, m in ipairs(IsInGroup() and LR.roster() or {}) do inGroup[U.foldCase(U.bare(m.name))] = m.name end end
  local out = {}
  for _, e in ipairs(list) do
    local key = U.foldCase(U.bare(e.p))
    -- (in the group: named the way the game names them)
    if not got[key] and (not here or inGroup[key]) then out[#out + 1] = here and { p = inGroup[key], n = e.n } or e end
  end
  return out
end
--- a wishlist as a short line: "Ann (1), Bob (2), +3"
function LR.wishLine(list, limit)
  local parts = {}
  for i, e in ipairs(list) do
    if i > (limit or 5) then parts[#parts + 1] = "+" .. (#list - i + 1) break end
    parts[#parts + 1] = ("%s (%d)"):format(U.short(U.full(e.p)), e.n)
  end
  return table.concat(parts, ", ")
end

--- everyone in the group and their LootRuler, the ones to do something about first:
--- { { name, class, version (nil: not heard from), state = "older" / "none" / "newer" / "same" (as mine) } }
function LR.versionList()
  local out = {}
  for _, m in ipairs(LR.roster()) do
    local v = LR.versionOf(m.name)
    local c = v and U.compareVersions(v, LR.VERSION)
    out[#out + 1] = { name = m.name, class = m.class, version = v, state = not v and "none" or c < 0 and "older" or c > 0 and "newer" or "same" }
  end
  local order = { older = 1, none = 2, newer = 3, same = 4 }
  table.sort(out, function(a, b)
    if a.state ~= b.state then return order[a.state] < order[b.state] end
    return a.name < b.name
  end)
  return out
end

--- whispers everyone in the group with an older LootRuler that there's a newer one (once each). Returns how many.
local toldOld = {}
function LR.tellOutdated()
  local n = 0
  for _, x in ipairs(LR.versionList()) do
    local key = U.full(x.name):lower()
    if x.state == "older" and toldOld[key] ~= x.version then
      toldOld[key] = x.version
      n = n + 1
      LR.say(("%s You have LootRuler %s, and %s is out. Yours still works with it, but update when you can."):format(LR.TAG, x.version, LR.VERSION), "WHISPER", x.name)
    end
  end
  return n
end

--- tells the group (or one player) we have the addon; not more than once every few seconds
local lastHello = {}
function LR.hello(target)
  local key = target or "group"
  if lastHello[key] and GetTime() - lastHello[key] < 10 then return end
  lastHello[key] = GetTime()
  if target then send({ t = "V" }, "WHISPER", target) return end
  local g = LR.groupChannel()
  if g then
    -- a few seconds' spread, so a raid answering the same question doesn't all speak at once
    C_Timer.After(math.random() * 2, function() send({ t = "V" }, LR.groupChannel()) end)
  end
end
function handlers.V() end       -- heardFrom has done the work

---------------------------------------------------------------------- start up
function LR.toast(text) if LR.UI and LR.UI.toast then LR.UI.toast(text) end end

local wasGrouped = false
local events = CreateFrame("Frame")
events:RegisterEvent("PLAYER_LOGIN")
events:RegisterEvent("GROUP_ROSTER_UPDATE")
events:RegisterEvent("GET_ITEM_INFO_RECEIVED")
-- (the group as last read is kept: Core/Net.lua's LR.roster. These change it without a roster update.)
events:RegisterEvent("UNIT_CONNECTION")
events:RegisterEvent("PARTY_LEADER_CHANGED")
events:RegisterEvent("UNIT_NAME_UPDATE")
events:SetScript("OnEvent", function(_, event)
  if event == "UNIT_CONNECTION" or event == "PARTY_LEADER_CHANGED" or event == "UNIT_NAME_UPDATE" then
    LR.rosterChanged()
  elseif event == "PLAYER_LOGIN" then
    if not db then LR.loadDB() end
    C_ChatInfo.RegisterAddonMessagePrefix(LR.PREFIX)
    Net:RegisterComm(LR.PREFIX, "OnComm")
    wasGrouped = IsInGroup()
    -- once the game has settled: ask what's open, re-send our own sessions and anything we picked meanwhile
    C_Timer.After(5, function()
      LR.query()
      LR.hello()
      for _, s in pairs(db.sessions) do
        if LR.isLeader(s) then LR.publish(s, true) else LR.sendPicks(s) end
      end
    end)
  elseif event == "GROUP_ROSTER_UPDATE" then
    LR.rosterChanged()
    if not db then return end
    local grouped = IsInGroup()
    if grouped and LR.Practice.on then LR.Practice.stop("you joined a group, so the practice raid is over: it's forgotten.") end
    if grouped and not wasGrouped then
      C_Timer.After(2, function()
        LR.query()
        LR.hello()
        for _, s in pairs(db.sessions) do
          if LR.isLeader(s) then LR.publish(s, true) else LR.sendPicks(s) end
        end
      end)
    end
    wasGrouped = grouped
    -- someone came online or joined: if it's a leader we have picks waiting for, send them
    for _, s in pairs(db.sessions) do if not LR.isLeader(s) then LR.sendPicks(s) end end
    LR.changed("roster")
  elseif event == "GET_ITEM_INFO_RECEIVED" then
    LR.changed("items")
  end
end)
